package Modelo;

import java.util.ArrayList;

public class Veterinario extends Persona {
    private String DNI;
    private String SegSocial;
    private ArrayList<Mascota> listaMascotas;

    public Veterinario(String nombre, String direccion, String telefono, String DNI, String segSocial, ArrayList<Mascota> listaMascotas) {
        super(nombre, direccion, telefono);
        this.DNI = DNI;
        SegSocial = segSocial;
        this.listaMascotas = listaMascotas;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getSegSocial() {
        return SegSocial;
    }

    public void setSegSocial(String segSocial) {
        SegSocial = segSocial;
    }

    public ArrayList<Mascota> getListaMascotas() {
        return listaMascotas;
    }

    public void setListaMascotas(ArrayList<Mascota> listaMascotas) {
        this.listaMascotas = listaMascotas;
    }
}
