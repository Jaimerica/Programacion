 import Emtidades .Persona;

         import javax. persistence .*;
 import javax.swing .*;
 import java.util.List;

         public class Main {
         public static void main(String [] args) {
         EntityManagerFactory emf =
                Persistence . createEntityManagerFactory ("default");
         EntityManager em = emf. createEntityManager ();
         EntityTransaction transaction = em. getTransaction ();

         try {

             // Insertar
             transaction .begin ();
             Persona p = new Persona ();
             p.setDni( JOptionPane . showInputDialog (null , "Teclea el dni de la persona a insertar "));
                     p. setNombre ( JOptionPane . showInputDialog (null , "Teclea el  nombrede la persona a insertar"));
                             em.persist(p);
             // Si hay una persona con ese dni dara error al hacer el ´
            commit.

             // Buscar
             p = new Persona ();
             p.setDni( JOptionPane . showInputDialog (null , "Teclea el dni de la persona a buscar"));
                     p = em.find(Persona.class ,p.getDni ());
             if (p != null)
                 JOptionPane . showMessageDialog (null ,p. getNombre () + " es el nombre de la persona encontrada ");
                     else
             JOptionPane . showMessageDialog (null , "Persona no encontrada ");

                     // Modificar
                     p = new Persona ();
             p.setDni( JOptionPane . showInputDialog (null , "Teclea el dni de la persona a modificar "));
                     p = em.find(Persona.class ,p.getDni ());
             if (p != null) {
                 p. setNombre ( JOptionPane . showInputDialog (null , "Teclea el nuevo nombre de la persona"));
                         em.persist(p);
                 }else
                 JOptionPane . showMessageDialog (null , "Persona no encontrada ");

                     // Borrar

                     p = new Persona ();
             p.setDni( JOptionPane . showInputDialog (null , "Teclea el dni de la persona a borrar"));

                         p = em.find(Persona.class ,p.getDni ());
             if (p != null) {
                 em.remove(p);
                 }else
                 JOptionPane . showMessageDialog (null , "Persona no encontrada ");
                     transaction .commit ();

             // Consultas varias
             transaction .begin ();

             Query qNroPersonas = em. createNativeQuery ("SELECT COUNT (*) FROM personas ");
                     JOptionPane . showMessageDialog (null ,"Hay " +
                            qNroPersonas . getSingleResult ());

             // Persona.todas es una consulta creada en la propia entidad.
             TypedQuery <Persona > qPersonas =
                    em. createNamedQuery ("Persona.todas", Persona.class);
             // Me devuelve una lista de objetos de tipo Persona
             List <Persona > lista = qPersonas . getResultList ();
             String datos ="";
             for(Persona per: lista)
                 datos += per.getDni () + " " + per. getNombre () + "\n";
             JOptionPane . showMessageDialog (null ,datos);

             // Consulta con parametro ´
             TypedQuery <Persona > qPersonaByNombre = em. createNamedQuery ("Persona.una", Persona.class);
             String nombre = JOptionPane . showInputDialog (null , "Teclea el nombre de la persona y yo te digo el dni");
                     qPersonaByNombre . setParameter (1, nombre);
             Persona pConsultada = qPersonaByNombre . getSingleResult ();
             JOptionPane . showMessageDialog (null ," El dni de " + nombre + " es " + pConsultada .getDni ());
                     // Si no hay salta excepcion´

                     }
         catch( Exception e)
         {
             JOptionPane . showMessageDialog (null ,e. getMessage ());
             }
         finally
         {
             if ( transaction .isActive ()) {
                 transaction .rollback ();
                 }
             em.close ();
             emf.close ();
             }
         }
 }
