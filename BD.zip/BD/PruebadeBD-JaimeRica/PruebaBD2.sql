 CREATE OR REPLACE PROCEDURE datos_emp32_scott_v2
 (
 --declaro parametro de entrada del tipo numerico
 p_sal IN NUMBER ,
 --declaro parametro de salida del tipo variable cursor
 p_cursor OUT SYS_REFCURSOR
 )
 AS
 V_ERROR VARCHAR2 (250);
 BEGIN
 -- Genero un cursor dinamico con los datos del enunciado
 OPEN p_cursor FOR
 SELECT EMPNO , ENAME ,JOB , MGR , HIREDATE , SAL , COMM , DEPTNO
 FROM scott.emp
 WHERE sal <= p_sal;

 EXCEPTION
 WHEN OTHERS THEN
 V_ERROR :=�Error Oracle: �|| TO_CHAR(SQLCODE)||�, �|| SQLERRM;
 RAISE_APPLICATION_ERROR (� -20000 � ,V_ERROR);
 END;
