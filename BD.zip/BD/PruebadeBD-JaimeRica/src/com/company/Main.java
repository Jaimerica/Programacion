package com.company;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class Main {

    public static void main(String[] args) {
	// write your code here

        try
         {
         Class.forName("oracle.jdbc. OracleDriver ");

         String url = "jdbc:oracle:thin:@172 .20.225.114:1521: orcl";
         String user = "root";
         String passwd = "usbw";
         Connection conn = DriverManager. getConnection (url ,user ,passwd);



         CallableStatement c = conn. prepareCall ("{call empresas_ejercicio1 (?)}");

         c. registerOutParameter (1, oracle.jdbc. OracleTypes .CURSOR);
         c.execute ();
         ResultSet rs = ( ResultSet )c. getObject (1);
         while(rs.next ()){
         System.out.println(rs. getString (2));
         }
         rs.close ();
         c.close ();

         c = conn. prepareCall ("{call empresas_ejercicio1 (? ,?)}");

         c.setInt (1 ,2500);
         c. registerOutParameter (2, oracle.jdbc. OracleTypes .CURSOR);

         c.execute ();
         rs = (ResultSet)c. getObject (2);
         while(rs.next ()){
             System.out.println(rs. getString (2));
             }
         rs.close ();
         c.close ();
         conn.close ();
         }
        catch ( Exception e) {
         System.out.println(e. getClass ());
        }}

    }
