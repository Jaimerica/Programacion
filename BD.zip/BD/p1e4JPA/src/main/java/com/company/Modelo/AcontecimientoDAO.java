package com.company.Modelo;

import javax.persistence.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class AcontecimientoDAO {

    private static EntityManagerFactory emf;
    private static EntityManager em;
    private static EntityTransaction transaction;
    private static Acontecimiento ac;

    public static String alta(Acontecimiento a) {
        String mensaje;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            em.persist(a);
            transaction.commit();
            mensaje =  "ok";
        }
        catch(Exception e)
        {
           mensaje = e.getMessage();
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();
        }
        return mensaje;
    }

    public static Acontecimiento consultarAcontecimiento(String n) {
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            ac = em.find(Acontecimiento.class,n);
            //transaction.commit();
        }
        catch(Exception e)
        {
           ac = null;
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();

            return ac;
        }
    }

    public static String borrar() {
        String mensaje;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            // Sin buscar otra vez no funciona.
            ac = em.find(Acontecimiento.class,ac.getNombre()); // lo tengo de la búsqueda anterior.
            em.remove(ac);
            transaction.commit();
            mensaje =  "ok";
        }
        catch(Exception e)
        {
            mensaje = e.getMessage();
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();
        }
        return mensaje;
    }

    public static List<Acontecimiento> consultarAcontecimientos() {
        List<Acontecimiento> lista=null;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            // Acontecimiento.todos es una consulta creada en la propia entidad.
            TypedQuery<Acontecimiento> qAcontecimientos = em.createNamedQuery("Acontecimiento.todos",Acontecimiento.class);
            // Me devuelve una lista de objetos de tipo Acontecimiento.
            lista = qAcontecimientos.getResultList();
        }
        catch(Exception e)
        {
            lista = null;
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();

            return lista;
        }
    }

    public  static String actualizar(Acontecimiento a) throws Exception {
        String mensaje;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            ac = em.find(Acontecimiento.class,a.getNombre());

            // Lo cambio.
            ac.setAforo(a.getAforo());
            ac.setLugar(a.getLugar());
            ac.setFecha(java.sql.Date.valueOf(a.getFecha()));
            ac.setHoraI(java.sql.Time.valueOf(a.getHoraI()));
            ac.setHoraF(java.sql.Time.valueOf(a.getHoraF()));

            em.persist(ac);
            transaction.commit();
            mensaje =  "ok";
        }
        catch(Exception e)
        {
            mensaje = e.getMessage();
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();
        }
        return mensaje;
    }

}
