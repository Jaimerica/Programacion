package com.company.Controlador;

import com.company.Vista.*;
import com.company.Modelo.Acontecimiento;
import com.company.Modelo.AcontecimientoDAO;

import javax.swing.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Main {

    private static JFrame vp;
    private static Acontecimiento a;
    private static List<Acontecimiento> listaAcontecimientos;

    public static void main(String[] args) {
        mostrarVentanaPrincipal();

    }

    public static void mostrarVentanaPrincipal()
    {
        vp = new JFrame("VentanaPrincipal");
        vp.setContentPane(new VentanaPrincipal().getpPrincipal());
        vp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        vp.setExtendedState(JFrame.MAXIMIZED_BOTH);
        vp.pack();
        vp.setVisible(true);

    }

    public static void mostrarInsertar()
    {
        // Mostrar el JDialog que permite introducir los datos de un evento
        DInsertar dialog = new DInsertar();
        dialog.setLocationRelativeTo(null);
        dialog.pack();
        dialog.setVisible(true);
    }

    public static String getDatosAcontecimiento(String n, String l, LocalDate f, LocalTime hi, LocalTime hf, int af) throws Exception
    {
        // Crear objeto y mandarlo a la base de datos
        // Cuidado. En la entity acontecimento el tipo de dato es java.sql.Date No LocalDate

        // Conversión LocalDate en java.sql.Date y LocalTime a java.sql.Time
        a = new Acontecimiento(n,l,java.sql.Date.valueOf(f),java.sql.Time.valueOf(hi),java.sql.Time.valueOf(hf),af);

        // Abrir, ejecutar y cerrar
        return AcontecimientoDAO.alta(a);
    }

    public static String cancelarEvento(String nombre) throws Exception
    {
        // Primero consulta
        a = AcontecimientoDAO.consultarAcontecimiento(nombre);
        if (a != null)
            return a.toString();

        throw new Exception("No hay ningún evento con ese nombre");
    }

    public static String borrarAcontecimiento() throws Exception{
       return AcontecimientoDAO.borrar();
    }

    public static void visualizarModificarEvento()
    {
        DModificacion dialog = new DModificacion();
        dialog.pack();
        dialog.setVisible(true);
    }

    public static ArrayList<String> datosLlenarCombo() throws Exception
    {
        listaAcontecimientos = AcontecimientoDAO.consultarAcontecimientos();
        if (listaAcontecimientos == null || listaAcontecimientos.size() == 0)
            throw new Exception("No hay eventos");

        // A la ventana van solo los nombres.
        ArrayList<String> nombres = new ArrayList<>();
        for(Acontecimiento a:listaAcontecimientos)
            nombres.add(a.getNombre());
        return nombres;
    }

    public static void getEventoSeleccionado(int i)
    {
        a = listaAcontecimientos.get(i);
    }

    public static String getLugar()
    {
        return a.getLugar();
    }

    public static String getFecha()
    {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return a.getFecha().format(formato);
    }

    public static String getHoraInicio()
    {
        return a.getHoraI().toString();
    }

    public static String getHoraFin()
    {
        return a.getHoraF().toString();
    }

    public static String getAforo()
    {
        return a.getAforo().toString();
    }

    public static String getDatosActualizados(String l, LocalDate f, LocalTime hi, LocalTime hf, int af) throws Exception
    {
        // Modificar objeto y mandarlo a la base de datos
        a.setLugar(l);
        // En la clase de tipo entidad no es LocalDate es java.sql.Date
        a.setFecha(java.sql.Date.valueOf(f));
        a.setHoraI(java.sql.Time.valueOf(hi));
        a.setHoraF(java.sql.Time.valueOf(hf));
        a.setAforo(af);

        // Abrir, ejecutar y cerrar
        return AcontecimientoDAO.actualizar(a);
    }
}
