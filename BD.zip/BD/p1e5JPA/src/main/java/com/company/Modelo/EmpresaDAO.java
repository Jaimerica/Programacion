package com.company.Modelo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class EmpresaDAO {

    private static EntityManagerFactory emf;
    private static EntityManager em;
    private static EntityTransaction transaction;
    private static Empresa emp;

   public static String alta(Empresa emp) {
        String mensaje;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            em.persist(emp);
            transaction.commit();
            mensaje =  "ok";
        }
        catch(Exception e)
        {
           mensaje = e.getMessage();
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();
        }
        return mensaje;
    }

}
