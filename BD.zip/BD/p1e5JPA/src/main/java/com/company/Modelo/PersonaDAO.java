package com.company.Modelo;

import javax.persistence.*;
import java.util.List;

public class PersonaDAO {

    private static EntityManagerFactory emf;
    private static EntityManager em;
    private static EntityTransaction transaction;
    private static Persona p;

   public static String alta(Persona p) {
        String mensaje;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            em.persist(p);
            transaction.commit();
            mensaje =  "ok";
        }
        catch(Exception e)
        {
           mensaje = e.getMessage();
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();
        }
        return mensaje;
    }

    public static Persona consultarPersona(String dni) {
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
           p = em.find(Persona.class,dni); // ya tengo dentro el objeto empresa.
            //transaction.commit();
        }
        catch(Exception e)
        {
           p= null;
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();

            return p;
        }
    }


}
