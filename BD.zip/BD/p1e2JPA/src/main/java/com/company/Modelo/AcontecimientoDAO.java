package com.company.Modelo;

import javax.persistence.*;
import javax.swing.*;
import java.util.List;

public class AcontecimientoDAO {

    private static EntityManagerFactory emf;
    private static EntityManager em;
    private static EntityTransaction transaction;

    public static String alta(Acontecimiento a) {
        String mensaje;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            em.persist(a);
            transaction.commit();
            mensaje =  "ok";
        }
        catch(Exception e)
        {
           mensaje = e.getMessage();
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();
        }
        return mensaje;
    }


}
