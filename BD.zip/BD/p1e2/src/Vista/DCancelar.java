package Vista;
import com.company.Main;

import javax.swing.*;

public class DCancelar {

    public JPanel getContentPane() {
        return contentPane;
    }

    public void setContentPane(JPanel contentPane) {
        this.contentPane = contentPane;
    }

    private JPanel contentPane;

    public static void main(String[] args) {
        JFrame frame = new JFrame("DCancelar");
        frame.setContentPane(new DCancelar().contentPane);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public void setLocationRelativeTo(Object o) {
    }

    public void pack() {
    }

    public void setVisible(boolean b) {
    }
}


