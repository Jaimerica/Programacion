package Vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.company.Main;

public class VentanaPrincipal{
    private JPanel pPrincipal;
    private JPanel pMenuBarra;
    private JPanel pImagen;
    private JMenu mAcontecimientos;
    private JMenuItem mInsertar;
    private JButton bInsertar;
    private JButton button1;
    private JButton bCancelar;
    private JMenuItem mCancelar;

    public VentanaPrincipal() {
        bInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.mostrarInsertar();
            }
        });

        mInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Main.mostrarInsertar();
                bInsertar.doClick();
            }
        });

        bCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.mostrarCancelar();
            }
        });

        mCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Main.mostrarCancelar();
                bCancelar.doClick();
            }
        });
    }

    public JPanel getpPrincipal() {
        return pPrincipal;
    }



}
