package com.company;
import Vista.Menu;

import javax.swing.*;
import java.sql.*;

public class Main {

    public static void main(String[] args) throws SQLException {
	// write your code here

        JFrame frame = new JFrame("Menu");
        frame.setContentPane(new Menu().getPantalla());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    try{
        Class.forName("com.mysql.cj.jdbc.Driver");


        String url = "jdbc:mysql://localhost:3307/prueba";
        String user = "root";
        String passwd = "usbw";
        Connection con = DriverManager.getConnection(url,user,passwd);


        Statement sentencia = con.createStatement();
        String s = "insert into tablauno values ('11111111B’,’pepe’)";
        sentencia.executeUpdate (s);

        con.close();
    }
    catch (Exception e)
    {
        System.out.println("Problemas con la base de datos " + e.getMessage());
    }
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch (ClassNotFoundException e)
        {

        }

        String url="jdbc:mysql://localhost:3307/"+"personas";
        Connection con = DriverManager.getConnection(url ,"root","usbw");

        Statement sentencia=con.createStatement();
        ResultSet resultado = sentencia.executeQuery("select * from persona");
        try {
            Statement valor = con.createStatement();
                    valor.executeUpdate("INSERT INTO persona VALUES('Jaime',22,'Estudiante','123456789')");
                    System.out.println("Fila insertada");
                    con.close();
        }
        catch (Exception e)
        {

        }

    }
}
