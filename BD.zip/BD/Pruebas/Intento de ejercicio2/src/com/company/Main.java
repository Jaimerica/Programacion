package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int nuevo = JOptionPane.showConfirmDialog(null,"Elige una de las tres opciones");
        if ((nuevo)==0)
            JOptionPane.showMessageDialog(null, "Potassium");
            else
            if ((nuevo)==1)
            JOptionPane.showMessageDialog(null,"¿Has dicho que no, verdad?");
            else
            if ((nuevo)==2)
            JOptionPane.showMessageDialog(null,"¡OH VENGA YA!");


        int otro = JOptionPane.showConfirmDialog(null,"Kris get the banana");
        if ((otro)==0)
            JOptionPane.showMessageDialog(null,"Potassium");
        else
            if ((otro)==1)
                JOptionPane.showMessageDialog(null,"Kris, que te vas a poner malito");
            else
                if ((otro)==2)
                    JOptionPane.showMessageDialog(null,"NO PUEDES CANCELARME, YO TE CANCELO A TI");

    }
}
