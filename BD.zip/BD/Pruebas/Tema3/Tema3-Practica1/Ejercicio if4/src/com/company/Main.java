package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n1;
        int n2;
        int n3;
        n1= Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Dame un número"));
        n2= Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Dame otro número"));
        n3= Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Dame el último número"));
        if (n1<n2 && n2<n3)
            javax.swing.JOptionPane.showMessageDialog(null,n3 +" Es el mayor y "+ n1 + " Es el menor.");
        else
            if (n2<n1 && n1<n3)
                javax.swing.JOptionPane.showMessageDialog(null,n3 +" Es el mayor y "+ n2 + " Es el menor.");
            else
                if (n1<n3 && n3<n2)
                    javax.swing.JOptionPane.showMessageDialog(null,n2 +" Es el mayor y "+ n1 + " Es el menor.");
                else
                    if (n2<n3 && n3<n1)
                        javax.swing.JOptionPane.showMessageDialog(null,n1 +" Es el mayor y "+ n2 + " Es el menor.");
                    else
                        if (n3<n2 && n2<n1)
                            javax.swing.JOptionPane.showMessageDialog(null,n1 +" Es el mayor y "+ n3 + " Es el menor.");
                        else
                            if (n3<n1 && n1<n2)
                                javax.swing.JOptionPane.showMessageDialog(null,n2 +" Es el mayor y "+ n3 + " Es el menor.");
    }
}
