package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        long nro = Long.parseLong(JOptionPane.showInputDialog("Teclea un número"));
        int contador = 0, nroImpar = 1;
        long resultado= 0;
        while(contador < nro)
        {
            resultado=resultado+nroImpar;
            nroImpar = nroImpar +2;
            contador = contador+1;
        }
        JOptionPane.showMessageDialog(null,resultado);
    }
}
