package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n1;
        int n2;
        int area;
        n1= Integer.parseInt (javax.swing.JOptionPane.showInputDialog("Dime el lado de un rectángulo"));
        n2= Integer.parseInt (javax.swing.JOptionPane.showInputDialog("Dame el otro lado del rectángulo"));
        area= 2*n1+2*n2;
        javax.swing.JOptionPane.showMessageDialog(null,area);
    }
}
