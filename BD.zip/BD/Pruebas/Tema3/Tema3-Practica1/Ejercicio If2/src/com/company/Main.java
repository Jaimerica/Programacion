package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n1;
        n1 = Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Dame la nota, entre el 0 y el 10"));
        switch (n1){
            case 0:
            case 1:
            case 2:
                javax.swing.JOptionPane.showMessageDialog(null,"Es un deficiente");
                break;
            case 3:
            case 4:
                javax.swing.JOptionPane.showMessageDialog(null,"Es un insuficiente");
                break;
            case 5:
                javax.swing.JOptionPane.showMessageDialog(null, "Es un suficiente");
                break;
            case 6:
                javax.swing.JOptionPane.showMessageDialog(null,"Es un bien");
                break;
            case 7:
            case 8:
                javax.swing.JOptionPane.showMessageDialog(null,"Es un notable");
                break;
            case 9:
            case 10:
                javax.swing.JOptionPane.showMessageDialog(null,"Es un sobresaliente");
                break;
        }

    }
}