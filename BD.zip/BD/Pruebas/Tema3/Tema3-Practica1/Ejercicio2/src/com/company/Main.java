package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n1;
        int n2;
        int resultado;
        n1= Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Dame un número"));
        n2= Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Dame otro número"));
        resultado=n1*n2;
        javax.swing.JOptionPane.showMessageDialog(null,resultado);
    }
}
