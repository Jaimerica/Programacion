package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n1;
        n1 = Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Dime el número de la semana"));
        switch (n1){
            case 0:
                javax.swing.JOptionPane.showMessageDialog(null,"¿Eso que es, la noche del Domingo la madrugada del Lunes?");
                break;
            case 1:
                javax.swing.JOptionPane.showMessageDialog(null,"Es otro Lunes");
                break;
            case 2:
                javax.swing.JOptionPane.showMessageDialog(null,"Martes, poco a poco");
                break;
            case 3:
                javax.swing.JOptionPane.showMessageDialog(null,"Miercoles, ya a la mitad");
                break;
            case 4:
                javax.swing.JOptionPane.showMessageDialog(null,"Jueves, no queda nada");
                break;
            case 5:
                javax.swing.JOptionPane.showMessageDialog(null, "Viernes, por fin");
                break;
            case 6:
                javax.swing.JOptionPane.showMessageDialog(null,"Sabado, toca descansar");
                break;
            case 7:
                javax.swing.JOptionPane.showMessageDialog(null,"Domingo y mañana otra vez a empezar");
                break;
        }
    }
}
