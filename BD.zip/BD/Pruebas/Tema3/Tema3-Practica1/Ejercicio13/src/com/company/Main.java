package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int contador = 0;
        int suma = 0;
        while(contador != 10)
        {
            int n = Integer.parseInt(JOptionPane.showInputDialog(null,"Teclea un número"));
            suma=suma+n;
            contador=contador+1;
        }
        JOptionPane.showMessageDialog(null,suma);
    }
}
