package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int contador;
        int contadorChicos = 0;
        int contadorChicas = 0;
        int peso;
        int edad;
        String nombre;
        String sexo;
        float estatura;

        for(contador = 0; contador < 30; contador++)
        {
            JOptionPane.showMessageDialog(null,"Teclea los datos de un alumno");
            peso = Integer.parseInt(JOptionPane.showInputDialog( null, "Teclea el peso" ));
            edad = Integer.parseInt(JOptionPane.showInputDialog(null, "Teclea la edad"));
            nombre = JOptionPane.showInputDialog(null,"Teclea el nombre");
            sexo = JOptionPane.showInputDialog(null,"Teclea el sexo").toLowerCase();
            estatura = Float.parseFloat(JOptionPane.showInputDialog(null,"Teclea la estatura"));

            if (sexo.equals("femenino"))
            {
                if (estatura > 1.6 && peso > 68)
                    contadorChicas += 1;
            }
            else
                if (estatura > 1.7 && peso > 70)
                    contadorChicos +=1;
        }
        JOptionPane.showMessageDialog(null,contadorChicos + " " + contadorChicas);
    }
}
