package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        float nota;
        int contadoraprobados = 0;
        String respuesta="si";
        while (respuesta.equalsIgnoreCase("si"))
        {
           nota =  Float.parseFloat(javax.swing.JOptionPane.showInputDialog("Dame la nota de un alumno"));
            if (nota >= 6.00)
            {
            contadoraprobados=contadoraprobados+1;
            }
            respuesta = javax.swing.JOptionPane.showInputDialog(null,"¿Quieres continuar?");
        }
        javax.swing.JOptionPane.showMessageDialog(null,contadoraprobados);
    }
}
