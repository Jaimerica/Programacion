package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int edad;
        int contadoraedad = 0;
        int totaledad = 0;
        int media = 0;
        String respuesta="si";
        while (respuesta.equalsIgnoreCase("si"))
        {
            edad =  Integer.parseInt(javax.swing.JOptionPane.showInputDialog("¿Que edad tiene?"));
                totaledad= totaledad+edad;
                contadoraedad=contadoraedad+1;
                respuesta = javax.swing.JOptionPane.showInputDialog(null,"¿Hay más gente?");
        }
        media = totaledad/contadoraedad;
        javax.swing.JOptionPane.showMessageDialog(null,media);
    }
}
