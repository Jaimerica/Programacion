package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        float gradosC = Float.parseFloat(javax.swing.JOptionPane.showInputDialog("Grados centígrados"));
        //float gradosF = 1.8 * gradosC + 32;
        double gradosF = 1.8 * gradosC + 32;
        //float gradosF = (float) 1.8 * gradosC +32;
        //float gradosF = 1.8f * gradosC + 32;

        System.out.println(gradosC + " 'C son " + gradosF + "'F son");
    }
}
