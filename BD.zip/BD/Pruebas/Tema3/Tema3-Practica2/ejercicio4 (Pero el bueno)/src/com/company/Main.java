package com.company;

import javax.swing.*;

public class Main {
    // Globales
    final private static int NUMEROASIGNATURAS = 6;
    private static int numeroAlumnos;
    private static float totalNotas;

    public static void main(String[] args)
    {
        String  nombre = JOptionPane.showInputDialog("Teclear el nombre: ");
        while(nombre.compareToIgnoreCase("fin")!= 0 )
        {
            // función que solicita las seis notas de un alumno
            float totalNotasAlumno = solicitarNotas();
            float medioAlumno=totalNotasAlumno / NUMEROASIGNATURAS;
            JOptionPane.showMessageDialog(null,nombre + " ha obtenido  " + medioAlumno + " de nota media");

            // función que realiza las operaciones necesarias para poder calcular la media de todos los alumnos.
            calculosMediaAlumnos(medioAlumno);

            nombre = JOptionPane.showInputDialog("Teclear el nombre: ");

        }
        JOptionPane.showMessageDialog(null, "La nota media de todos los alumnos es: "+ (totalNotas / numeroAlumnos));

    }

    public static float solicitarNotas()
    {
        float totalNotasAlumno = 0;
        for (int x = 0; x < NUMEROASIGNATURAS; x++)
        {
            float nota=0;
            boolean correcto;
            do
            {
                correcto = true;
                nota = Float.parseFloat(JOptionPane.showInputDialog("Teclear la nota de asignatura " + (x + 1) + ": "));
                if (nota < 0 || nota > 10)
                    correcto = false;
            }
            while(!correcto);
            totalNotasAlumno += nota;
        }
        return totalNotasAlumno; // devuelve la suma de las seis notas
    }

    public static void calculosMediaAlumnos(float mediaAlumno)
    {
        totalNotas += mediaAlumno; // suma de todas las notas medias
        numeroAlumnos++; // número de alumnos.
    }

}

