package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
int horas;
horas = Integer.parseInt(JOptionPane.showInputDialog("¿Cuántas horas ha estado trabajando este trabajador en su trabajo?"));
        int salariobase;
        if (horas<40)
        {
            salariobase= horas*30;
        }
        else
            if (horas>40)
            {
                salariobase= (40*30)+((horas-40)*45);
            }
    }
}
