package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String opc = JOptionPane.showInputDialog("Cliente \n"
                + "Cuenta \n"
                + "Saldo inicial \n"
                + "Reintegro \n\n"
                + "Cambio de cuenta");


    }
}
