package Excepciones;

public class NumerosNoValidosException extends Exception{
}
