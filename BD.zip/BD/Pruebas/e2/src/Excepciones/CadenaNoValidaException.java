package Excepciones;

public class CadenaNoValidaException extends Exception{
}
