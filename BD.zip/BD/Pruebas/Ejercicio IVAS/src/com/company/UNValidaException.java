package com.company;

public class UNValidaException extends Exception
{
}
