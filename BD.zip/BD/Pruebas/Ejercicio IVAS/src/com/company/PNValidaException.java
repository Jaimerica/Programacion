package com.company;

public class PNValidaException extends Exception{
}
