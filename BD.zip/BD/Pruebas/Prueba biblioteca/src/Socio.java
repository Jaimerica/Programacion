public class Socio extends Persona {
    String Nombre;
    String libro;
    String categoría;
    String color;
    int precio;
    int año;
    String autor;
    int fecha_salida;
    int fecha_entrada;
    int ID;

    public Socio(String nombre, String libro, String categoría, String color, int precio,
                 int año, String autor, int fecha_salida, int fecha_entrada, int ID) {
        this.Nombre = nombre;
        this.libro = libro;
        this.categoría = categoría;
        this.color = color;
        this.precio = precio;
        this.año = año;
        this.autor = autor;
        this.fecha_salida = fecha_salida;
        this.fecha_entrada = fecha_entrada;
        this.ID = ID;
    }

    public Socio(String nombre, int ID) {
        this.Nombre = nombre;
        this.ID = ID;
    }

    public void Alquilar()
    {

    }

    public void Reservar()
    {

    }

    public void Archivar()
    {

    }

}
