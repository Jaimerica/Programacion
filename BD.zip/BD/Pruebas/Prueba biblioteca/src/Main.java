public class Main {
    public static void main(String[] args) {
        Socio Ana=new Socio("Ana",0001);



        Bibliotecario Eva=new Bibliotecario(9,"Eva","Pérez");
    }
}
