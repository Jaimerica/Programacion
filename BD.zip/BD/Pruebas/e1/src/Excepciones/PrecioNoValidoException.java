package Excepciones;

public class PrecioNoValidoException extends Exception{
}
