package Excepciones;

public class IvaNoValidoException extends Exception{
}
