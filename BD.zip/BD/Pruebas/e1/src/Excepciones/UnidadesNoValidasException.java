package Excepciones;

public class UnidadesNoValidasException extends Exception {
}
