package com.company;

import Vista.VentanaCuartearia;
import Vista.VentanaPrincipal;
import Vista.VentanaSecundaria;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        {
            JFrame frame = new JFrame("VentanaPrincipal");
            frame.setContentPane(new VentanaPrincipal().getPanelPrincipal());
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
        }

        JFrame frame = new JFrame("VentanaSecundaria");
        frame.setContentPane(new VentanaSecundaria().getPanel1());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);


        JFrame frame2 = new JFrame("VentanaCuartearia");
        frame.setContentPane(new VentanaCuartearia().getPanel1());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    // Main.tenDatos(tfNombre.gettext(),tfApellidos.gettext(),---------)
}
