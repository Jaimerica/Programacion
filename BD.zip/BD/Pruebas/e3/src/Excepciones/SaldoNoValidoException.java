package Excepciones;

public class SaldoNoValidoException extends Exception {
}
