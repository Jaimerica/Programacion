package Excepciones;

public class TipoNoValidoException extends Exception{
}
