package Excepciones;

public class NombreNoValidoException extends Exception{
}
