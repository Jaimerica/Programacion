package com.company;

import Excepciones.*;

import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Main {

    public static void main(String[] args) {
        try
        {
            // Varios clientes
            int continuar;
            do
            {
                solicitarDatosCliente();
                continuar = JOptionPane.showConfirmDialog(null,"¿ Hay más clientes?");
            }
            while(continuar == 0);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Problemas: " + e.getMessage());
        }
    }

    public static void solicitarDatosCliente() throws Exception
    {
        String nombre = solicitarNombre();
        int masCuentas;
        // Varias cuentas por cliente
        do
        {
            String cuenta = solicitarNumeroCuenta();
            Double saldo = solicitarSaldo();
            saldo = solicitarMovimientos(saldo);
            JOptionPane.showMessageDialog(null, " El saldo actualizado de la cuenta " +
                    cuenta + " del cliente " + nombre + " al día " + LocalDate.now() +
                    " asciende a " + saldo);

            masCuentas = JOptionPane.showConfirmDialog(null, "¿ " + nombre + " tiene más cuentas?");
        }
        while(masCuentas == 0);
    }

    public static String solicitarNombre() throws Exception
    {
        // Solicitar y validar el nombre del cliente
        boolean error=true;
        String nombre="";
        do
        {
            try
            {
                nombre = JOptionPane.showInputDialog("Nombre del cliente");
                if (nombre.isEmpty())
                    throw new NombreNoValidoException();
                // un nombre no lleva números.
                int x;
                for(x = 0; x < nombre.length() && !Character.isDigit(nombre.charAt(x));x++){}
                if (x != nombre.length())
                    throw new NombreNoValidoException();
                error = false;
            }
            catch(NombreNoValidoException | NullPointerException e)
            {
                JOptionPane.showMessageDialog(null, "El nombre del cliente no puede contener números o estar vacío.");

            }
        }
        while(error);
        return nombre;
    }

    public static String solicitarNumeroCuenta() throws Exception
    {
        // Solicitar y validar el número de cuenta
        boolean error=true;
        String numeroCuenta="";
        do
        {
            try
            {
                numeroCuenta = JOptionPane.showInputDialog("Teclea el número de cuenta");
                // Supongo que un número de cuenta está formado por 10 números.
                if (numeroCuenta.length() != 10)
                    throw new CuentaNoValidaException();
                int x;
                for(x = 0; x < numeroCuenta.length() && Character.isDigit(numeroCuenta.charAt(x));x++){}
                if (x != numeroCuenta.length())
                    throw new CuentaNoValidaException();
                error = false;
            }
            catch(CuentaNoValidaException | NullPointerException e)
            {
                JOptionPane.showMessageDialog(null, "El número de cuenta no puede contener letras ni estar vacío.");

            }
        }
        while(error);
        return numeroCuenta;
    }

    public static Double solicitarSaldo() throws Exception
    {
        // Solicitar y validar el saldo inicial de la cuenta
        boolean error=true;
        Double saldo = 0.0;
        do
        {
            try
            {
                saldo= Double.parseDouble(JOptionPane.showInputDialog("Teclea el saldo inicial de la cuenta"));
                if (saldo < 0)
                    throw new SaldoNoValidoException();
                error = false;
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "El saldo debe ser un dato numérico.");

            }
            catch(SaldoNoValidoException e)
            {
                JOptionPane.showMessageDialog(null, "El saldo no puede ser negativo.");

            }
        }
        while(error);
        return saldo;
    }

    public static Double solicitarMovimientos(double saldo) throws Exception
    {
        // Solicitar los datos de los movimientos de la cuenta.
        double importe = solicitarImporte();
        while(importe !=0)
        {
            String tipo = solicitarTipo();
            LocalDate fecha = solicitarFecha();
            saldo = actualizarSaldo(saldo,tipo,importe);
            importe = solicitarImporte();
        }
        return saldo;
    }

    public static Double solicitarImporte() throws Exception
    {
        // Solicitar y validar el importe del movimiento.
        // Podemos intentar reutilizar el método solicitarSaldo
        boolean error=true;
        Double importe = 0.0;
        do
        {
            try
            {
                importe= Double.parseDouble(JOptionPane.showInputDialog("Teclea el importe del movimiento o 0 para finalizar"));
                if (importe < 0)
                    throw new ImporteNoValidoException();
                error = false;
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "El importe debe ser un dato numérico.");

            }
            catch(ImporteNoValidoException e)
            {
                JOptionPane.showMessageDialog(null, "El importe no puede ser menor que cero.");

            }
        }
        while(error);
        return importe;
    }

    public static String solicitarTipo() throws Exception
    {
        // Solicitar y validar el tipo (reintegro o imposición) del movimiento.
        boolean error=true;
        String tipo="";
        do
        {
            try
            {
                tipo = JOptionPane.showInputDialog("Teclea el tipo de movimiento (reintegro o imposición)");
                if (tipo.isEmpty())
                    throw new TipoNoValidoException();
                if (!tipo.equalsIgnoreCase("reintegro") && !tipo.equalsIgnoreCase("imposición"))
                    throw new TipoNoValidoException();
                error = false;
            }
            catch(TipoNoValidoException | NullPointerException e)
            {
                JOptionPane.showMessageDialog(null, "El tipo de movimiento no puede estar vacío y tiene que ser reintegro o imposición");

            }
        }
        while(error);
        return tipo;
    }

    public static LocalDate solicitarFecha() throws Exception
    {
        // Solicitar y validar la fecha del movimiento.
        boolean error=true;
        LocalDate fecha=null;
        do
        {
            try
            {
                String f = JOptionPane.showInputDialog("Teclea la fecha del movimiento");
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                fecha = LocalDate.parse(f, formatter);
                // No puede ser posterior a la de hoy
                if (fecha.isAfter(LocalDate.now()))
                    throw new FechaNoValidaException();

                error = false;
            }
            catch(DateTimeParseException | FechaNoValidaException | NullPointerException e)
            {
                JOptionPane.showMessageDialog(null, "El fecha no es válida.");

            }
        }
        while(error);
        return fecha;
    }

    public static Double actualizarSaldo(Double saldo, String tipo,Double importe) throws Exception
    {
        // Sumar o restar el importe del movimiento.
        if (tipo.equalsIgnoreCase("reintegro"))
            saldo = saldo - importe;
        else
            saldo = saldo + importe;
        return saldo;
    }
}
