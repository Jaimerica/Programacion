package com.company.Modelo;

import javax.persistence.*;
import javax.swing.*;
import java.util.List;

public class AcontecimientoDAO {

    private static EntityManagerFactory emf;
    private static EntityManager em;
    private static EntityTransaction transaction;
    private static Acontecimiento ac;

    public static String alta(Acontecimiento a) {
        String mensaje;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            em.persist(a);
            transaction.commit();
            mensaje =  "ok";
        }
        catch(Exception e)
        {
           mensaje = e.getMessage();
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();
        }
        return mensaje;
    }

    public static Acontecimiento consultarAcontecimiento(String n) {
        String mensaje;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            ac = em.find(Acontecimiento.class,n);
            //transaction.commit();
        }
        catch(Exception e)
        {
           ac = null;
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();

            return ac;
        }
    }

    public static String borrar() {
        String mensaje;
        try
        {
            emf = Persistence.createEntityManagerFactory("default");
            em = emf.createEntityManager();
            transaction = em.getTransaction();
            transaction.begin();
            // Sin buscar otra vez no funciona.
            ac = em.find(Acontecimiento.class,ac.getNombre()); // lo tengo de la búsqueda anterior.
            em.remove(ac);
            transaction.commit();
            mensaje =  "ok";
        }
        catch(Exception e)
        {
            mensaje = e.getMessage();
        }
        finally
        {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            em.close();
            emf.close();
        }
        return mensaje;
    }
}
