package com.company.Controlador;

import com.company.Vista.*;
import com.company.Modelo.Acontecimiento;
import com.company.Modelo.AcontecimientoDAO;

import javax.swing.*;
import java.time.LocalDate;
import java.time.LocalTime;

public class Main {

    private static JFrame vp;
    private static Acontecimiento a;

    public static void main(String[] args) {
        mostrarVentanaPrincipal();

    }

    public static void mostrarVentanaPrincipal()
    {
        vp = new JFrame("VentanaPrincipal");
        vp.setContentPane(new VentanaPrincipal().getpPrincipal());
        vp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        vp.setExtendedState(JFrame.MAXIMIZED_BOTH);
        vp.pack();
        vp.setVisible(true);

    }

    public static void mostrarInsertar()
    {
        // Mostrar el JDialog que permite introducir los datos de un evento
        DInsertar dialog = new DInsertar();
        dialog.setLocationRelativeTo(null);
        dialog.pack();
        dialog.setVisible(true);
    }

    public static String getDatosAcontecimiento(String n, String l, LocalDate f, LocalTime hi, LocalTime hf, int af) throws Exception
    {
        // Crear objeto y mandarlo a la base de datos
        // Cuidado. En la entity acontecimento el tipo de dato es java.sql.Date No LocalDate

        // Conversión LocalDate en java.sql.Date y LocalTime a java.sql.Time
        a = new Acontecimiento(n,l,java.sql.Date.valueOf(f),java.sql.Time.valueOf(hi),java.sql.Time.valueOf(hf),af);

        // Abrir, ejecutar y cerrar
        return AcontecimientoDAO.alta(a);
    }

    public static String cancelarEvento(String nombre) throws Exception
    {
        // Primero consulta
        a = AcontecimientoDAO.consultarAcontecimiento(nombre);
        if (a != null)
            return a.toString();

        throw new Exception("No hay ningún evento con ese nombre");
    }

    public static String borrarAcontecimiento() throws Exception{
       return AcontecimientoDAO.borrar();
    }
}
