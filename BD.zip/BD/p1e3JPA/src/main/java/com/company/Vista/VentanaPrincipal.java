package com.company.Vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.company.Controlador.Main;

public class VentanaPrincipal {
    private JPanel pPrincipal;
    private JButton bInsertar;
    private JButton bCancelar;

    public static void main(String[] args) {
        JFrame frame = new JFrame("VentanaPrincipal");
        frame.setContentPane(new VentanaPrincipal().pPrincipal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getpPrincipal() {
        return pPrincipal;
    }

    public void validarNombre(String n) throws Exception
    {
        if (n.isEmpty())
            throw new Exception("El nombre es un dato obligatorio");
        // Expresión regular para comprobar letras
    }

    public VentanaPrincipal() {
        bInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.mostrarInsertar();
            }
        });
        bCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try
                {
                    String nombre = JOptionPane.showInputDialog(null, "Teclea el nombre del evento que quieres cancelar");
                    validarNombre(nombre);
                    String datos = Main.cancelarEvento(nombre);
                    int respuesta = JOptionPane.showConfirmDialog(null, "¿Estás seguro de borrar de forma definitiva el evento " + datos);
                    if (respuesta == 0)
                    {
                        String mensaje = Main.borrarAcontecimiento();
                        if (mensaje.equals("ok"))
                            JOptionPane.showMessageDialog(null, "Evento cancelado");
                        else
                            throw new Exception(mensaje);
                    }
                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }

            }
        });
    }
}
