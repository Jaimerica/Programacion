package com.company.Modelo;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Time;

@Entity
@Table(name = "acontecimientos", schema = "bdacontecimientos", catalog = "")
public class Acontecimiento {
   // @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "nombre", nullable = false, length = 40)
    private String nombre;
    @Basic
    @Column(name = "lugar", nullable = false, length = 40)
    private String lugar;
    @Basic
    @Column(name = "fecha", nullable = false)
    private Date fecha;
    @Basic
    @Column(name = "hora_i", nullable = false)
    private Time horaI;
    @Basic
    @Column(name = "hora_f", nullable = false)
    private Time horaF;
    @Basic
    @Column(name = "aforo", nullable = false)
    private int aforo;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHoraI() {
        return horaI;
    }

    public void setHoraI(Time horaI) {
        this.horaI = horaI;
    }

    public Time getHoraF() {
        return horaF;
    }

    public void setHoraF(Time horaF) {
        this.horaF = horaF;
    }

    public int getAforo() {
        return aforo;
    }

    public void setAforo(int aforo) {
        this.aforo = aforo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Acontecimiento that = (Acontecimiento) o;

        if (aforo != that.aforo) return false;
        if (nombre != null ? !nombre.equals(that.nombre) : that.nombre != null) return false;
        if (lugar != null ? !lugar.equals(that.lugar) : that.lugar != null) return false;
        if (fecha != null ? !fecha.equals(that.fecha) : that.fecha != null) return false;
        if (horaI != null ? !horaI.equals(that.horaI) : that.horaI != null) return false;
        if (horaF != null ? !horaF.equals(that.horaF) : that.horaF != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = nombre != null ? nombre.hashCode() : 0;
        result = 31 * result + (lugar != null ? lugar.hashCode() : 0);
        result = 31 * result + (fecha != null ? fecha.hashCode() : 0);
        result = 31 * result + (horaI != null ? horaI.hashCode() : 0);
        result = 31 * result + (horaF != null ? horaF.hashCode() : 0);
        result = 31 * result + aforo;
        return result;
    }

    public Acontecimiento(String nombre, String lugar, Date fecha, Time horaI, Time horaF, int aforo) {
        this.nombre = nombre;
        this.lugar = lugar;
        this.fecha = fecha;
        this.horaI = horaI;
        this.horaF = horaF;
        this.aforo = aforo;
    }

    public Acontecimiento(String nombre) {
        this.nombre = nombre;
    }

    public Acontecimiento() {
    }

    @Override
    public String toString(){
        return nombre + " " + lugar + " " + fecha + " " + getHoraI() + " " + getHoraF() + " "  + aforo;
    }
}
