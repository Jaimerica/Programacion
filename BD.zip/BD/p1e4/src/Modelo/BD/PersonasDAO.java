package Modelo.BD;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import Modelo.UML.Persona;

public class PersonasDAO {
    private  static Persona acontecimiento;

    private  static PreparedStatement sentenciaPre;
    private  static String plantilla;
    private  static Statement sentencia;
    private  static ResultSet resultado;

    public  static void alta(Persona ac) throws Exception
    {
        /* Método que inserta una fila en la tabla de los acontecimientos a partir de un objeto de tipo acontecimiento.
        Este método también se suele llamar save.*/

        // Abrir la conexión
        BaseDatos.abrirBD();

        // Preparar la sentencia que se quiere ejecutar
        plantilla = "INSERT INTO personas (nombre, apellido, telefono, DNI) VALUES (?,?,?,?,?,?)";
        sentenciaPre = BaseDatos.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,ac.getNombre());
        sentenciaPre.setString(2,ac.getApellido());
        sentenciaPre.setString(3, ac.getTelefono());
        sentenciaPre.setString(4, ac.getDNI());

        // Ejecutar sentencia
        int n = sentenciaPre.executeUpdate();
        System.out.println( n + "filas insertadas");

        // Cerrar la conexión
        BaseDatos.cerrarBD();
    }


    public static java.sql.Time conversionTime(java.time.LocalTime hora)
    {
        // Conversion java.time.LocalTime en java.sql.Time
        return java.sql.Time.valueOf(hora);
    }

    public static Persona consultarPersona(String n) throws Exception{

        BaseDatos.abrirBD();

        plantilla = "select *  from personas where nombre = ?";
        sentenciaPre = BaseDatos.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,n);

        resultado = sentenciaPre.executeQuery();
        if (resultado.next())
        {
            crearObjeto();
        }
        else
            throw new Exception("No hay ninguna persona con ese nombre");

        BaseDatos.cerrarBD();

        return acontecimiento;
    }

    public static void crearObjeto() throws Exception
    {
        acontecimiento = new Persona();
        acontecimiento.setNombre(resultado.getString("nombre"));
        acontecimiento.setDNI(resultado.getString("DNI"));
        acontecimiento.setTelefono(resultado.getString("telefono"));
        acontecimiento.setDNI("DNI");
    }

    public static void borrar(Persona ac) throws Exception{

        BaseDatos.abrirBD();
        plantilla = "delete from personas where nombre = ?";
        sentenciaPre = BaseDatos.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,ac.getNombre());

        int n = sentenciaPre.executeUpdate();
        if (n == 0)
            throw new Exception();

        System.out.println( n + " filas borradas");

        BaseDatos.cerrarBD();
    }

    public static ArrayList<Persona> consultarPersonas() throws Exception{

        // Método que consultar un acontecimiento de la base de datos
        BaseDatos.abrirBD();

        plantilla = "select *  from personas";
        sentenciaPre = BaseDatos.getCon().prepareStatement(plantilla);

        // Podía ser un Statement

        resultado = sentenciaPre.executeQuery();
        ArrayList<Persona> lista = new ArrayList<>();
        while (resultado.next())
        {
            crearObjeto();
            lista.add(acontecimiento);
        }

        BaseDatos.cerrarBD();

        return lista;
    }

    public  static void actualizar(Persona ac) throws Exception
    {

        // Abrir la conexión
        BaseDatos.abrirBD();

        // Preparar la sentencia que se quiere ejecutar
        plantilla = "update personas set nombre = ?, apellido = ?, telefono = ?, DNI = ?";
        sentenciaPre = BaseDatos.getCon().prepareStatement(plantilla);
        sentenciaPre = BaseDatos.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,ac.getNombre());
        sentenciaPre.setString(2,ac.getApellido());
        sentenciaPre.setString(3, ac.getTelefono());
        sentenciaPre.setString(4, ac.getDNI());

        // Ejecutar sentencia
        int n = sentenciaPre.executeUpdate();
        System.out.println( n + "filas modificadas");


        // Cerrar la conexión
        BaseDatos.cerrarBD();
    }

}
