package Vista;

import javax.swing.*;
import com.company.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Inicio {
    private JTextField CampoNombre;
    private JTextField CampoApellido;
    private JLabel NombreNombre;
    private JLabel ApellidoApellido;
    private JButton ConfirmarBoton;
    private JPanel Panel;

    public Inicio() {
        ConfirmarBoton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.MostrarConfirmacion();
            }
        });
    }

    public JTextField getCampoNombre() {
        return CampoNombre;
    }

    public void setCampoNombre(JTextField campoNombre) {
        CampoNombre = campoNombre;
    }

    public JTextField getCampoApellido() {
        return CampoApellido;
    }

    public void setCampoApellido(JTextField campoApellido) {
        CampoApellido = campoApellido;
    }

    public JButton getConfirmarBoton() {
        return ConfirmarBoton;
    }

    public void setConfirmarBoton(JButton confirmarBoton) {
        ConfirmarBoton = confirmarBoton;
    }

    public JPanel getPanel() {
        return Panel;
    }

    public void setPanel(JPanel panel) {
        Panel = panel;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Inicio");
        frame.setContentPane(new Inicio().Panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
