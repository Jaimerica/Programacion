package com.company;

import Extensiones.Persona;
import Extensiones.novalido;

import javax.swing.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// write your code here
        ArrayList<Persona> listaPersona;
        listaPersona = ObtenerDatosPersonas();
    }

    public static ArrayList<Persona> ObtenerDatosPersonas(){
        ArrayList<Persona> lista = new ArrayList();
        do
        {
            try
            {
                String Nombre = JOptionPane.showInputDialog("Ponga el nombre de la persona");
                int DNacimiento = Integer.parseInt(JOptionPane.showInputDialog("ingresa el día de nacimiento"));
                int MNacimiento = Integer.parseInt(JOptionPane.showInputDialog("ingresa el mes de nacimiento"));
                int ANacimiento = Integer.parseInt(JOptionPane.showInputDialog("ingresa el año de nacimiento"));
                String Direccion = JOptionPane.showInputDialog("Ponga su dirección");
                String CPostal = JOptionPane.showInputDialog("Ponga el código postal");
                String Ciudad = JOptionPane.showInputDialog("¿En qué ciudad reside?");

                Persona a = new Persona(Nombre,DNacimiento,MNacimiento,ANacimiento,Direccion,CPostal,Ciudad);

                lista.add(a);

                LocalDate.of(ANacimiento,MNacimiento,DNacimiento);
            } catch(Exception e)
            {
                JOptionPane.showMessageDialog(null,"Problemas");
            }
        }
        while(JOptionPane.showConfirmDialog(null,"¿ Quieres ingresar mas personas?")==0);
        return lista;
    }



}
