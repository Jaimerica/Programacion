package Extensiones;

public class Persona {
    private String Nombre;
    private int DNacimiento;
    private int MNacimiento;
    private int ANacimiento;
    private String Direccion;
    private String CPostal;
    private String Ciudad;

    public Persona(String nombre, int DNacimiento, int MNacimiento, int ANacimiento, String direccion, String CPostal, String ciudad) {
        Nombre = nombre;
        this.DNacimiento = DNacimiento;
        this.MNacimiento = MNacimiento;
        this.ANacimiento = ANacimiento;
        Direccion = direccion;
        this.CPostal = CPostal;
        Ciudad = ciudad;
    }
}


