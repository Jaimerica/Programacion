package Extensiones;

public class novalido extends Exception{
}
