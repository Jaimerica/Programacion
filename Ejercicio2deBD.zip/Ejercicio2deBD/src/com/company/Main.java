package com.company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

    public static void main(String[] args) {
	// write your code here
        try
         {
             Class.forName("com.mysql.cj.jdbc.Driver");

             String url = "jdbc:mysql :// localhost :3307/ prueba";
             String user = "root";
             String passwd = "usbw";
             Connection con = DriverManager. getConnection (url , user , passwd);

             Statement sentencia = con. createStatement ();
             String s = "insert into tablauno  values ( ’11111111B’,’pepe ’)";
             sentencia . executeUpdate (s);

             con.close ();
             }
         catch( Exception e)
         {
             System.out.println(" Problemas con la base de datos " + e. getMessage ());
            }


        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection( "url" ,"root","usbw");
        }
        catch (ClassNotFoundException | SQLException e)
        {

        }

        String url="jdbc:mysql :// localhost :3307/"+"basedatos";

    }
}
