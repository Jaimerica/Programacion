package Vista;

import javax.swing.*;

public class Menu {
    private JPanel panel1;
    private JPanel Titulo;
    private JPanel Nombre;
    private JPanel Contabilizar;
    private JPanel DatosComp;
    private JPanel DatosVent;
    private JPanel Botones;
    private JPanel Descuentos;
    private JTextField textField1;
    private JTextField textField2;
    private JLabel NombProdu;
    private JLabel Unidades;
    private JRadioButton compraRadioButton;
    private JRadioButton ventaRadioButton;
    private JTextField textField3;
    private JComboBox comboBox1;
    private JCheckBox porVolumenCheckBox;
    private JCheckBox porProntoPagoCheckBox;
    private JTextField textField4;
    private JButton aceptarButton;
    private JButton cancelarButton;
    private JTextField textField5;
    private JTextField textField6;
    private JTextField textField7;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Menu");
        frame.setContentPane(new Menu().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getPanel1() {
        return panel1;
    }

    public void setPanel1(JPanel panel1) {
        this.panel1 = panel1;
    }
}
