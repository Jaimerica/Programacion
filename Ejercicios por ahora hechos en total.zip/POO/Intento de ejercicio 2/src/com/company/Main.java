package com.company;
import Modelo.Producto;
import Vista.Menu;

import javax.swing.*;
import java.util.ArrayList;

public class Main {
    private static ArrayList<Producto> listaProductos;
    public static Producto p;

    public static void main(String[] args) {
	// write your code here
        JFrame frame = new JFrame("Menu");
        frame.setContentPane(new Menu().getPanel1());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    listaProductos= new ArrayList<Producto>();
    p = new Producto("Manzanas",1.5f,100);

    }
}
