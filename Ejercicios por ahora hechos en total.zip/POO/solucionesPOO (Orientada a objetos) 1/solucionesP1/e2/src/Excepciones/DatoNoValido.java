package Excepciones;

public class DatoNoValido extends Exception{

}
