package com.company;
import Modulo.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

public class Main {

    private static Empleado[] listaempleados;

    private static Directivo[] listaDirectivos;

    public static void main(String[] args) {

        try{
            crearEmpleado();
            crearDirectivo();
            buscarDirectivosconmasempleados();
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(null,e.getClass());
        }
    }
    public static void crearEmpleado() throws Exception{

        listaempleados = new Empleado[5];

        listaempleados[0] = new Empleado(10000,"Jaime",22, "Marketing");
        listaempleados[1] = new Empleado(15000,"Anne",21,"Dirección");
        listaempleados[2] = new Empleado(12500,"Jean",25,"Finanzas");
        listaempleados[3] = new Empleado(6000,"Mirei",35,"Marketing");
        listaempleados[4] = new Empleado(18000,"Marco Antonio",72,"Dirección");
    }
    public static void crearDirectivo() throws Exception{

        listaDirectivos = new Directivo[3];

        listaDirectivos[0] = new Directivo("Dirección",50000,"Arion",54);
        listaDirectivos[1] = new Directivo("Marketing",28000,"Nagore",49);
        listaDirectivos[2] = new Directivo("Finanzas", 34000,"Ivory", 67);
    }

    public static void buscarDirectivosconmasempleados() throws Exception{
        float  maximo = 0;
        Directivo cargo = null;
        for (int x=0; x<listaempleados.categoria();x++);
    }
}