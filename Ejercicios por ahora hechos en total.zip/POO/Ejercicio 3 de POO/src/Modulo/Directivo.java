package Modulo;

public class Directivo {
    private String categoría;
    private int Sueldobruto;
    private String nombre;
    private int edad;

    public Directivo(String categoría, int sueldobruto, String nombre, int edad) {
        this.categoría = categoría;
        Sueldobruto = sueldobruto;
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getCategoría() {
        return categoría;
    }

    public void setCategoría(String categoría) {
        this.categoría = categoría;
    }

    public int getSueldobruto() {
        return Sueldobruto;
    }

    public void setSueldobruto(int sueldobruto) {
        Sueldobruto = sueldobruto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}


