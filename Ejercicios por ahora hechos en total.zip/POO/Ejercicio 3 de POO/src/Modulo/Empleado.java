package Modulo;

public class Empleado {
    private int Sueldobruto;
    private String nombre;
    private int edad;
    private String categoria;

    public Empleado(int sueldobruto, String nombre, int edad, String categoria) {
        Sueldobruto = sueldobruto;
        this.nombre = nombre;
        this.edad = edad;
        this.categoria = categoria;
    }

    public int getSueldobruto() {
        return Sueldobruto;
    }

    public void setSueldobruto(int sueldobruto) {
        Sueldobruto = sueldobruto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}
