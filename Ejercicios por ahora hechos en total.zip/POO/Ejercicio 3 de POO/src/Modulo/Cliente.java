package Modulo;

import java.util.ArrayList;

public class Cliente {
    private ArrayList<String> telefono;
    private String nombre;
    private int edad;

    public Cliente(ArrayList<String> telefono, String nombre, int edad) {
        this.telefono = telefono;
        this.nombre = nombre;
        this.edad = edad;
    }

    public ArrayList<String> getTelefono() {
        return telefono;
    }

    public void setTelefono(ArrayList<String> telefono) {
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}