package Modelo;

import java.util.Date;

public class Perro extends Mascota{
    private int longitud;

    public Perro(String animal, String raza, String nombre, Date fecha_nacimiento, String sexo, int peso, String pelo, int longitud) {
        super(animal, raza, nombre, fecha_nacimiento, sexo, peso, pelo);
        this.longitud = longitud;
    }

    public int getLongitud() {
        return longitud;
    }

    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }
}
