package Modelo;

import java.util.ArrayList;

public class Cliente extends Persona{
    private ArrayList<Mascota> listaMascotas;

    public Cliente(String nombre, String direccion, String telefono, ArrayList<Mascota> listaMascotas) {
        super(nombre, direccion, telefono);
        this.listaMascotas = listaMascotas;
    }

    public ArrayList<Mascota> getListaMascotas() {
        return listaMascotas;
    }

    public void setListaMascotas(ArrayList<Mascota> listaMascotas) {
        this.listaMascotas = listaMascotas;
    }
}
