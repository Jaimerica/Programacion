package Modelo;

import java.util.Date;

public class Gato extends Mascota {
    public Gato(String animal, String raza, String nombre, Date fecha_nacimiento, String sexo, int peso, String pelo) {
        super(animal, raza, nombre, fecha_nacimiento, sexo, peso, pelo);
    }

}
