package com.company;

import Modelo.Cliente;
import Modelo.Mascota;
import Modelo.Persona;
import Modelo.Veterinario;

import javax.swing.*;
import java.util.ArrayList;

public class Main {

    private static Cliente[] listaClientes;
    private static Veterinario[] listaVeterinarios;


    private static ArrayList<Mascota> listaMascotas;

    public static void main(String[] args) {
	// write your code here

        try{
            CrearClientes();
            CrearMascotas();
            CrearVeterinarios();
        }
        catch (Exception e){
            javax.swing.JOptionPane.showMessageDialog(null,e.getClass());
        }
    }

    public static void CrearClientes() throws Exception{
        listaClientes = new Cliente[5];
        listaClientes [0] = new Cliente("Jeando","C/ San Fras","987544321",1);

    }



    public static void CrearMascotas() throws Exception{
        listaMascotas = new ArrayList();
        ArrayList <Mascota> lista = new ArrayList();
        lista.add(listaMascotas[1]);
        listaMascotas.add(new Mascota("Perro","Pastor Alemán","Lyss",07/08/1998,"Macho","85","Marrón"));


    }


    public static void CrearVeterinarios() throws Exception{
        listaVeterinarios = new Veterinario[3];
        listaVeterinarios = new Veterinario("Karol","C/ Los Santis","965444888","9854321D","467872546757234","1")

    }
}
