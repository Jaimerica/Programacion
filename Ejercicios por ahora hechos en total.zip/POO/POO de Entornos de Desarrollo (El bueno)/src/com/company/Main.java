package com.company;

import Modelo.Cuenta;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Cuenta cuenta_1 = new Cuenta("Maria");
        Cuenta cuenta_2 = new Cuenta("Maria", 300);


        cuenta_1.ingresar(300);
        cuenta_2.ingresar(400);

        cuenta_1.retirar(500);
        cuenta_2.retirar(100);

        System.out.println(cuenta_1.toString());
        System.out.println(cuenta_2.getCantidad());
    }
}

/* Otro ejercicio
        public class Libro{
        private int ISBN;
        private String titulo;
        private String autor;
        private int numPaginas;

realizar un constructor, para generar:
        public libro(int ISBN, String titulo, String autor, int numPaginas) {

        ISBN = pISBN
        titulo = pTitulo
        autor = pAutor
        numPaginas = pNumPaginas


        public int getISBN { return ISBN {

        public void setISBN(int ISBN) {this.ISBN = ISBN {

 */


/*


 */
