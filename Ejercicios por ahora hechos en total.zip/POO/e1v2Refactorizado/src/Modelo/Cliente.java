package Modelo;

public class Cliente extends Persona
{
    public Cliente(String nombre, String direccion, String telefono) {
        super(nombre, direccion, telefono);
    }
}
