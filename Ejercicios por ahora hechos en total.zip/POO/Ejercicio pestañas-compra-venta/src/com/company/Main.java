package com.company;

import Vista.V1;

import javax.swing.*;

public class Main {

    private static JFrame V1;

    public static void main(String[] args) {
	// write your code here
        V1 = new JFrame("V1");
        V1.setContentPane(new V1().getPanelPrincipal());
        V1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        V1.setLocationRelativeTo(null);
        V1.pack();
        V1.setVisible(true);
    }


}
