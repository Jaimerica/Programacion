package Vista;

import javax.swing.*;
import com.company.*;

import java.security.Principal;

public class V1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("V1");
        frame.setContentPane(new V1().PanelPrincipal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private JPanel Principal;
    private JButton bCompra;
    private JButton bVenta;
    private JButton bSalir;
    private JPanel PanelPrincipal;

    public V1(JPanel principal, JButton bCompra, JButton bVenta, JButton bSalir, JPanel panelPrincipal) {
        Principal = principal;
        this.bCompra = bCompra;
        this.bVenta = bVenta;
        this.bSalir = bSalir;
        PanelPrincipal = panelPrincipal;
    }

    public JPanel getPrincipal() {
        return Principal;
    }

    public void setPrincipal(JPanel principal) {
        Principal = principal;
    }

    public JButton getbCompra() {
        return bCompra;
    }

    public void setbCompra(JButton bCompra) {
        this.bCompra = bCompra;
    }

    public JButton getbVenta() {
        return bVenta;
    }

    public void setbVenta(JButton bVenta) {
        this.bVenta = bVenta;
    }

    public JButton getbSalir() {
        return bSalir;
    }

    public void setbSalir(JButton bSalir) {
        this.bSalir = bSalir;
    }

    public JPanel getPanelPrincipal() {
        return PanelPrincipal;
    }

    public void setPanelPrincipal(JPanel panelPrincipal) {
        PanelPrincipal = panelPrincipal;
    }

    public V1(){



    }
}
