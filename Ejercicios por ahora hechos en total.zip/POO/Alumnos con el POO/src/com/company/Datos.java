package com.company;

public interface Datos {

    public void Darsedealta();
}
