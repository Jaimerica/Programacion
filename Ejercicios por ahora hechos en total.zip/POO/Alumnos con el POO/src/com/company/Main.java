package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here

Alumno Pepe=new Alumno("pepe","lopez",1);
Pepe.setNombre("Jose");
System.out.println(Pepe.getNombre());

Pepe.Darsedealta();
    }
}
