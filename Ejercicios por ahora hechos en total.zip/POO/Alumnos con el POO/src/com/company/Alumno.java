package com.company;

public class Alumno implements Datos{

    private String nombre;
    private String apellido;
    private int código;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getCódigo() {
        return código;
    }

    public void setCódigo(int código) {
        this.código = código;
    }

    public Alumno(String nombre, String apellido, int código) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.código = código;


    }

    @Override
    public void Darsedealta() {

    }
}
