package Modelo;

public class No_perecedero extends Producto{
private String Tipo;

    public No_perecedero(String nombre, int precio) {
        super(nombre, precio);

    }

    public No_perecedero(String nombre, int precio, String tipo) {
        super(nombre, precio);
        Tipo = tipo;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    @Override
    public String toString() {
        return "No_perecedero{" +
                "Tipo='" + Tipo + '\'' +
                '}';
    }
    public int calcular (int cantidad){
        int total = cantidad * this.getPrecio();
        return total;
    }
}
