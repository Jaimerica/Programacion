package Modelo;

public class Perecedero extends Producto{
    private int dias_a_caducar;

    public Perecedero(String nombre, int precio, int dias_a_caducar) {
        super(nombre, precio);
        this.dias_a_caducar = dias_a_caducar;
    }

    public Perecedero(String nombre, int precio) {
        super(nombre, precio);


    }

    public int getDias_a_caducar() {
        return dias_a_caducar;
    }

    public void setDias_a_caducar(int dias_a_caducar) {
        this.dias_a_caducar = dias_a_caducar;
    }

    @Override
    public String toString() {
        return "Perecedero{" +
                "dias_a_caducar='" + dias_a_caducar + '\'' +
                '}';
    }

    public int calcular (int cantidad){
        int total=0;
        if (dias_a_caducar == 1){
             total = (cantidad * this.getPrecio())/4;
        }
        else
            if (dias_a_caducar == 2){
                 total = (cantidad * this.getPrecio())/3;
            }
            else
            if (dias_a_caducar == 3){
                 total = (cantidad * this.getPrecio())/2;
            }
        return total;

    }
}
