package com.company;

import Modelo.No_perecedero;
import Modelo.Perecedero;
import Modelo.Producto;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Producto[] productos = new Producto[4];


        productos[0] = new Perecedero("Producto 1",10,3);
        productos[1] = new Perecedero("Producto 2",20,1);
        productos[2] = new No_perecedero("Producto 3",5,"tipo 1");
        productos[3] = new Producto("p1",23);

        double total = 0;
        for (int i = 0; i < productos.length; i++) {
            total += productos[i].calcular(5);
            System.out.println(("El producto " +  productos[i].getNombre()+ " su precio sería " + productos));
        }

        for (int i = 0; i < productos.length; i++) {
            if (productos[i] instanceof Perecedero)
                System.out.println(productos[i]);
        }

    }
}
