package com.company;

import javax.swing.*;
import javax.swing.JOptionPane;
import java.text.DecimalFormat;
import Excepciones.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
       // double radio = Double.parseDouble(JOptionPane.showInputDialog("Teclea el radio del objeto"));
       // double longitud = 2 * Math.PI * radio;
       // double area = Math.PI * radio * radio;
       // double volumen = 4* Math.PI * radio * radio * radio /3;
       // JOptionPane.showMessageDialog(null, "Si el radio es " + radio + " la longitud será "
        // + longitud + " su área será " + area + " y su volumen será " + volumen);

        try
        {
            double r = Double.parseDouble(JOptionPane.showInputDialog("Teclea un radio"));
            if ( r <= 0)
                throw new novalido();

            Radio c = new Radio();
            c.setRadio(r);

            DecimalFormat df = new DecimalFormat("#.00");
            JOptionPane.showMessageDialog(null,"Los datos de la circunferencia son:"+
                    "\n Longitud: "+ df.format(c.getLongitud())+
                    "\n Área:" + df.format(c.getArea())+
                    "\n Volumen: "+ c.getVolumen());
        }
        catch(NumberFormatException e)
        {
            JOptionPane.showMessageDialog(null,"Error, el dato es de tipo numerico");
        }
        catch(novalido e)
        {
            JOptionPane.showMessageDialog(null,"Error, el dato es incorrecto");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Error" + e.getMessage());
        }

    }
}
