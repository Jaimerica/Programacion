package Excepciones;

    public class novalido extends Exception {

    }
