package Modelo;
import com.company.*;

import java.util.ArrayList;

public class Cliente {
    private String nombre;
    private String NIF;
    private ArrayList<Cliente> listaClientes;

    public Cliente(String NIF){
        this.NIF = NIF;
        listaClientes = new ArrayList();
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNIF() {
        return NIF;
    }

    public void setNIF(String NIF) {
        this.NIF = NIF;
    }

    public ArrayList<Cliente> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }

}
