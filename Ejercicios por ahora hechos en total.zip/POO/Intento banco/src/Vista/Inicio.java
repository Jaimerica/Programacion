package Vista;

import com.company.Main;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Inicio {
    private JPanel Panel;
    private JButton accesoOnlineButton;
    private JButton ImagenKutxa;





    public Inicio() {
        accesoOnlineButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.mostrarV2();
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Menu");
        frame.setContentPane(new Inicio().Panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }


    public JButton getAccesoOnlineButton() {
        return accesoOnlineButton;
    }



    public JButton getButton1() {
        return ImagenKutxa;
    }

    public void setButton1(JButton button1) {
        this.ImagenKutxa = button1;
    }

    public JPanel getPanel() {
        return Panel;
    }

    public void setPanel(JPanel panel) {
        Panel = panel;
    }


}


