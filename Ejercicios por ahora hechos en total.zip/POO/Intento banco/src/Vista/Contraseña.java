package Vista;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Contraseña {
    private JPanel panel2;
    private JTextField CampoNIF;
    private JButton button1;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JButton button6;
    private JButton button7;
    private JButton button8;
    private JButton button9;
    private JButton button10;
    private JButton AccesoMenu;
    private JLabel PanelNIF;
    private JLabel PanelClave;
    private JPasswordField CampoClave;
    private JLabel DatosNIF;


    public Contraseña() {
        AccesoMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.mostrarV3();
            }
        });
    }

    public static void accesoOnlineButton(String[] args) {
        JFrame frame = new JFrame("Contraseña");
        frame.setContentPane(new Contraseña().panel2);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getPanel2() {
        return panel2;
    }

    public void setPanel2(JPanel panel2) {
        this.panel2 = panel2;
    }

    public JTextField getCampoNIF() {
        return CampoNIF;
    }

    public void setCampoNIF(JTextField campoNIF) {
        CampoNIF = campoNIF;
    }

    public JButton getButton1() {
        return button1;
    }

    public void setButton1(JButton button1) {
        this.button1 = button1;
    }

    public JButton getButton2() {
        return button2;
    }

    public void setButton2(JButton button2) {
        this.button2 = button2;
    }

    public JButton getButton3() {
        return button3;
    }

    public void setButton3(JButton button3) {
        this.button3 = button3;
    }

    public JButton getButton4() {
        return button4;
    }

    public void setButton4(JButton button4) {
        this.button4 = button4;
    }

    public JButton getButton5() {
        return button5;
    }

    public void setButton5(JButton button5) {
        this.button5 = button5;
    }

    public JButton getButton6() {
        return button6;
    }

    public void setButton6(JButton button6) {
        this.button6 = button6;
    }

    public JButton getButton7() {
        return button7;
    }

    public void setButton7(JButton button7) {
        this.button7 = button7;
    }

    public JButton getButton8() {
        return button8;
    }

    public void setButton8(JButton button8) {
        this.button8 = button8;
    }

    public JButton getButton9() {
        return button9;
    }

    public void setButton9(JButton button9) {
        this.button9 = button9;
    }

    public JButton getButton10() {
        return button10;
    }

    public void setButton10(JButton button10) {
        this.button10 = button10;
    }

    public JButton getButton11() {
        return AccesoMenu;
    }

    public void setButton11(JButton button11) {
        this.AccesoMenu = button11;
    }

    public JLabel getPanelNIF() {
        return PanelNIF;
    }

    public void setPanelNIF(JLabel panelNIF) {
        PanelNIF = panelNIF;
    }

    public JLabel getPanelClave() {
        return PanelClave;
    }

    public void setPanelClave(JLabel panelClave) {
        PanelClave = panelClave;
    }

    public JPasswordField getCampoClave() {
        return CampoClave;
    }

    public void setCampoClave(JPasswordField campoClave) {
        CampoClave = campoClave;
    }

}
