package Vista;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu {
    private JMenu Resumen;
    private JMenu Tarjetas;
    private JMenu Inversiones;
    private JMenu Mercados;
    private JMenu Prestamos;
    private JMenu Seguros;
    private JMenu Servicios;
    private JMenu Cuentas;
    private JPanel JPanel3;
    private JMenuItem Datos;
    private JMenuItem Personal;
    private JMenuItem Asistente;
    private JMenuItem Credito;
    private JMenuItem Débito;
    private JMenuItem Virtuales;
    private JMenuItem Deudas;
    private JMenuItem Cobros;
    private JMenuItem Facturas;
    private JMenuItem Bolsa;
    private JMenuItem Criptomonedas;
    private JMenuItem NFT;
    private JMenuItem Acciones;
    private JMenuItem PedirPrestamo;
    private JMenuItem PendientePrestamo;
    private JMenuItem HistorialPrestamos;
    private JMenuItem VerSeguros;
    private JMenuItem DatosServicios;
    private JMenuItem RecibirServicios;
    private JMenuItem ConsultaCuentas;
    private JMenuItem MovimientosCuentas;


    public static void main(String[] args) {
        JFrame frame = new JFrame("Menu");
        frame.setContentPane(new Menu().JPanel3);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JMenu getResumen() {
        return Resumen;
    }

    public void setResumen(JMenu resumen) {
        Resumen = resumen;
    }

    public JMenu getTarjetas() {
        return Tarjetas;
    }

    public void setTarjetas(JMenu tarjetas) {
        Tarjetas = tarjetas;
    }

    public JMenu getInversiones() {
        return Inversiones;
    }

    public void setInversiones(JMenu inversiones) {
        Inversiones = inversiones;
    }

    public JMenu getMercados() {
        return Mercados;
    }

    public void setMercados(JMenu mercados) {
        Mercados = mercados;
    }

    public JMenu getPrestamos() {
        return Prestamos;
    }

    public void setPrestamos(JMenu prestamos) {
        Prestamos = prestamos;
    }

    public JMenu getSeguros() {
        return Seguros;
    }

    public void setSeguros(JMenu seguros) {
        Seguros = seguros;
    }

    public JMenu getServicios() {
        return Servicios;
    }

    public void setServicios(JMenu servicios) {
        Servicios = servicios;
    }

    public JMenu getCuentas() {
        return Cuentas;
    }

    public void setCuentas(JMenu cuentas) {
        Cuentas = cuentas;
    }

    public JPanel getJPanel3() {
        return JPanel3;
    }

    public void setJPanel3(JPanel JPanel3) {
        this.JPanel3 = JPanel3;
    }

    public JMenuItem getConsultaCuentas() {
        return ConsultaCuentas;
    }

    public void setConsultaCuentas(JMenuItem consultaCuentas) {
        ConsultaCuentas = consultaCuentas;
    }

    public JMenuItem getMovimientosCuentas() {
        return MovimientosCuentas;
    }

    public void setMovimientosCuentas(JMenuItem movimientosCuentas) {
        MovimientosCuentas = movimientosCuentas;
    }


}

