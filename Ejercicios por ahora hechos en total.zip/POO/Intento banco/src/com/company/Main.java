package com.company;
import Modelo.Cliente;
import Vista.*;

import javax.swing.*;
import java.util.ArrayList;

public class Main {

    private static ArrayList<Cliente> lClientes;
    private static Cliente oCliente;
    private static Cliente[] aCliente;


    public static void main(String[] args) {
	// write your code here
            JFrame frame = new JFrame("Menu");
            frame.setContentPane(new Inicio().getPanel());
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
            CrearDatos();
    }

    public static void CrearDatos(){
        lClientes = new ArrayList();
        aCliente = new Cliente[2];
        aCliente[0] = new Cliente("74635352G");
        aCliente[1] = new Cliente("6746201YJ");
        aCliente[2] = new Cliente("23457890Z");
    }



    public static void mostrarV2() {
        JFrame frame = new JFrame("Contraseña");
        frame.setContentPane(new Contraseña().getPanel2());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public static void mostrarV3() {
        JFrame frame = new JFrame("Menu");
        frame.setContentPane(new Menu().getJPanel3());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }



}
