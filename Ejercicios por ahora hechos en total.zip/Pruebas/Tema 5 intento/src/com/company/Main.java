package com.company;

import javax.swing.*;
import javax.xml.bind.annotation.XmlEnum;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Main {

    private static ArrayList<Float> lista = new ArrayList();

    public static void main(String[] args) {
	// write your code here

        CompletarArrayList();

        int menu = Integer.parseInt( JOptionPane.showInputDialog("Decida la operacion a realizar"
                + "\n 1.Mostrar  el valor máximo y mínimo"
                + "\n 2.Buscar número"
                + "\n 3.Borrar número"
                + "\n 4.Convertir el arraylist en array"
                + "\n 5.Mostrar números de elementos que contiene el array"
                + "\n 6.Insertar nuevo elemento en la posición indicada"
                + "\n 7.Borrar un elemento de una posición concreta"
                + "\n 8.Calcular la suma y la media arimética de los valores contenidos"
                + "\n 9.Finalizar"));

        switch(menu){
            case 1: CompletarArrayList();
                break;

            case 2: buscarnumero();
                break;

            case 3: borrarnumero();
                break;

            case 4: convertirarray();
                break;

            case 5: mostrar();
                break;

            case 6: insertar();
                break;

            case 7: borrar();
                break;

            case 8: calcularsuma();
                break;

            case 9: salir();
                break;
            }
        }

    public static void CompletarArrayList() {
        int contador = 0;
        do {
            lista.add(Float.parseFloat(JOptionPane.showInputDialog("Ponga un numero")));
            contador =  JOptionPane.showConfirmDialog(null, "¿Deseas continuar?");
        } while (contador ==0);
        System.out.println(Collections.max(lista));
        System.out.println(Collections.min(lista));

    }
    public static void buscarnumero() {

        int buscar = Integer.parseInt( JOptionPane.showInputDialog("Ingresa el número a buscar"))-1;
        Float numero= lista.get(buscar);
        JOptionPane.showMessageDialog(null, "El número está en " + numero);
    }
    public static void borrarnumero() {
        int borrar = Integer.parseInt(JOptionPane.showInputDialog("Seleccione la posición a borrar"));
        Float numero= lista.remove(borrar);
        JOptionPane.showMessageDialog(null, "El numero a eliminar es " + numero);
        JOptionPane.showMessageDialog(null, "El numero ha sido eliminado");
    }
    public static void convertirarray() {
        Object[]miarray = lista.toArray();
        JOptionPane.showMessageDialog(null, Arrays.toString(miarray));
    }

    public static void mostrar() {
        JOptionPane.showMessageDialog(null,lista.size());
    }

    public static void insertar() {
        float Final=Float.parseFloat(JOptionPane.showInputDialog("Introduzca la posición donde ingresar el numero"));
        lista.add(Final);
    }

    public static void borrar() {
        int borrar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la posición a eliminar"));
        lista.remove(borrar);
    }

    public static void calcularsuma() {
        float suma=0;
        for(int x=0;x<lista.size();x++){
            suma += lista.get(0);
            JOptionPane.showMessageDialog(null, "La suma de toda la operación es " + suma);
        }

    }

    public static void salir() {
        System.exit(0);
    }
}
