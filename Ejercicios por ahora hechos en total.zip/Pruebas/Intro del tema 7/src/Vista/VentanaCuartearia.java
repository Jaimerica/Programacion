package Vista;

import javax.swing.*;

public class VentanaCuartearia {
    private JPanel panel1;
    private JButton aceptarButton;
    private JButton salirButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;

    public static void main(String[] args) {
        JFrame frame2 = new JFrame("VentanaCuartearia");
        frame2.setContentPane(new VentanaCuartearia().panel1);
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.pack();
        frame2.setVisible(true);
    }

    public JPanel getPanel1() {
        return panel1;
    }
}
