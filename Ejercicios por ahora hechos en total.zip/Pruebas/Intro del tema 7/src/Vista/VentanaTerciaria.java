package Vista;

import javax.swing.*;

public class VentanaTerciaria {
    private JPanel panel1;
}
