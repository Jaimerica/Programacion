package Vista;

import javax.swing.*;

public class VentanaPrincipal {
    public static void main(String[] args) {
        JFrame frame = new JFrame("VentanaPrincipal");
        frame.setContentPane(new VentanaPrincipal().panelPrincipal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getPanelPrincipal() {
        return panelPrincipal;
    }

    private JPanel panelPrincipal;
    private JButton Aceptar;
    private JButton Salir;
    private JTextField DNISitio;
    private JTextField ApellidoSitio;
    private JTextField NombreSitio;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
