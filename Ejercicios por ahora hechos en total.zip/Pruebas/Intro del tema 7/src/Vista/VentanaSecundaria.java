package Vista;

import javax.swing.*;

public class VentanaSecundaria {

    private JPanel panel1;
    private JTextField jTextField;
    private JButton Salir;

    public JPanel getPanel1() {
        return panel1;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("VentanaSecundaria");
        frame.setContentPane(new VentanaSecundaria().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);


    }
}
