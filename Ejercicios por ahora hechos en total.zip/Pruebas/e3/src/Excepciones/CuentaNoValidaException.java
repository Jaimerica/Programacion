package Excepciones;

public class CuentaNoValidaException extends Exception{
}
