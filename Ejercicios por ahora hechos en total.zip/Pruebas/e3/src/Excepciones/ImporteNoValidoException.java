package Excepciones;

public class ImporteNoValidoException extends Exception {
}
