package Excepciones;

public class FechaNoValidaException extends Exception{
}
