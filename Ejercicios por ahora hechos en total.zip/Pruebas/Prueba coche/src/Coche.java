public class Coche {

    int velocidad;
    String modelo;
    String marca;
    float capacidad_tanque;
    String color;
    int año;
    int autonomía;
    String tipo;
    int marcha;
    String matricula;

    public Coche(int velocidad, String modelo, String marca, float capacidad_tanque, String color,
                 int año, int autonomía, String tipo, int marcha, String matricula) {
        this.velocidad = velocidad;
        this.modelo = modelo;
        this.marca = marca;
        this.capacidad_tanque = capacidad_tanque;
        this.color = color;
        this.año = año;
        this.autonomía = autonomía;
        this.tipo = tipo;
        this.marcha = marcha;
        this.matricula = matricula;
    }

    public Coche() {
    }

    public Coche(String modelo, String marca, String matricula) {
        this.modelo = modelo;
        this.marca = marca;
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return "Coche{" +
                "velocidad=" + velocidad +
                ", modelo='" + modelo + '\'' +
                ", marca='" + marca + '\'' +
                ", capacidad_tanque=" + capacidad_tanque +
                ", color='" + color + '\'' +
                ", año=" + año +
                ", autonomía=" + autonomía +
                ", tipo='" + tipo + '\'' +
                ", marcha=" + marcha +
                ", matricula='" + matricula + '\'' +
                '}';
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void Arrancar(){
        System.out.println("hemos arrancado el coche");
    }

    public void Frenar(){
        System.out.println("coche frenado");
    }

    public void abrir_cerrar_puertas(){
        System.out.println("trabajando con las puertas");
    }

    public void acelerar(){
        this.velocidad=this.velocidad+10;
        System.out.println("Acerelar");

    }

    public void cambiar_marcha(){
        System.out.println("cambiamos de marcha");
    }





}
