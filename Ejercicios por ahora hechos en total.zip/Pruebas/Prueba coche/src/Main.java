import java.util.Arrays;

public class Main {

    public static void main(String[] args) {

        Coche Cochedepepe=new Coche("Ibiza","Seat","0123-lkj");
        Cochedepepe.Arrancar();
        Cochedepepe.acelerar();
        Cochedepepe.acelerar();
        Cochedepepe.acelerar();
        Cochedepepe.Frenar();


        Coche Cochedemaria= new Coche();
        Cochedemaria.Arrancar();
        Cochedemaria.Frenar();

        //Cochedemaria.color="verde";
        Cochedemaria.setColor("verde");
        System.out.println("El color del coche de Maria es: " + Cochedemaria.getColor());

        Cochedepepe.setColor("azul");
        System.out.println("El color del coche de Pepe es: " + Cochedepepe.getColor());
        System.out.println(Cochedepepe.toString());
    }
}
