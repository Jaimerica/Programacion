package com.company;

import javax.swing.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

    public static void main(String[] args) {
	// write your code here
        boolean error = false;
        do {
            try
            {
                String fechaString = JOptionPane.showInputDialog("Dame una fecha en formato dd/MM/yy");
                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yy");
                Date fechaUno = formato.parse(fechaString);

                long milisegundos = fechaUno.getTime() + (100*24*60*60*1000);
                long nfecha = milisegundos/86400000;

                JOptionPane.showMessageDialog(null, "la nueva fecha es "+ nfecha);
                error = false;

            }
            catch(ParseException e)
            {
                JOptionPane.showMessageDialog(null, "Problemas con la fecha");
                error = true;
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Problemas " + e.getClass());
            }
        }
        while (error);
    }
}
