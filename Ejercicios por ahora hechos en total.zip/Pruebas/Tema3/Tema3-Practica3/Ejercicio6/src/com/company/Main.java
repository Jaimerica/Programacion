package com.company;

import javax.swing.*;
import java.time.DateTimeException;
import java.time.LocalDate;


public class Main {

    public static void main(String[] args) {
	// write your code here
            LocalDate hoy = LocalDate.now();
            int año=hoy.getYear();
            final LocalDate PRIMAVERA = LocalDate.of(año,3,21);
            final LocalDate VERANO = LocalDate.of(año,6,21);
            final LocalDate OTOÑO = LocalDate.of(año,9,21);
            final LocalDate INVIERNO = LocalDate.of(año,12,21);

            boolean error;
            do
            {
               try
               {
                   int dia = Integer.parseInt(JOptionPane.showInputDialog("Teclea el día"));
                   int mes = Integer.parseInt(JOptionPane.showInputDialog("Teclea el mes"));
                   LocalDate fecha = LocalDate.of(año,mes,dia);

                   if (fecha.isBefore(PRIMAVERA))
                       JOptionPane.showMessageDialog(null,"Invierno");
                   else
                       if (fecha.isBefore(VERANO))
                           JOptionPane.showMessageDialog(null,"Primavera");
                       else
                           if (fecha.isBefore(OTOÑO))
                               JOptionPane.showMessageDialog(null,"Verano");
                           else
                               if (fecha.isBefore(INVIERNO))
                                   JOptionPane.showMessageDialog(null,"Otoño");
                               else
                                   JOptionPane.showMessageDialog(null,"Invierno");
                               error = false;
               }
               catch (DateTimeException e)
               {
                   JOptionPane.showMessageDialog(null,"Error en la selección de días o meses");
                   error= true;
               }
               catch (Exception e)
               {
                   JOptionPane.showMessageDialog(null,"Problemas");
                   error= true;
               }
            }
            while (error);
    }
}
