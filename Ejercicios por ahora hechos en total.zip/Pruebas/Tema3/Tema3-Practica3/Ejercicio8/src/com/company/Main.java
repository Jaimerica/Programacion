package com.company;

import javax.swing.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Main {

    public static void main(String[] args) {
	// write your code here
    try
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String fechaString = JOptionPane.showInputDialog("teclea tu fecha de nacimiento dd/MM/yyyy");
        LocalDate fechaNacimiento = LocalDate.parse(fechaString, formatter);

        LocalDate hoy = LocalDate.now();
        Period periodo = Period.between(fechaNacimiento, hoy);

        JOptionPane.showMessageDialog(null, "Tienes " + periodo.getYears() + " años.");
    }
    catch (DateTimeParseException e)
    {
        JOptionPane.showMessageDialog(null, "La fecha seleccionada no es correcta");
    }
    catch (Exception e)
    {
        JOptionPane.showMessageDialog(null,"Problemas " + e.getClass());
    }
    }
}
