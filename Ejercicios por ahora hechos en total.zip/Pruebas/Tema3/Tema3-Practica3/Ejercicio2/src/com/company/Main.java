package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String cadena = javax.swing.JOptionPane.showInputDialog("Dime una frase");
        for(int y = cadena.length()-1; y >=0; y--);
        {
            cadenainvertida = cadenainvertida + cadena.charAt(y);
        }
        JOptionPane.showMessageDialog(null, "La cadena invertida es " + cadenainvertida);
    }
}
