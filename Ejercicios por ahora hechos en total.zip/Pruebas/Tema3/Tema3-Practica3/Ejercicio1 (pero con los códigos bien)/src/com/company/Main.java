package com.company;

public class Main {
    public static void main(String[] args) {
        // write your code here
        int nVocales = 0;
        String mensaje = javax.swing.JOptionPane.showInputDialog("Dame una frase");
        System.out.println(mensaje.length());
        mensaje.charAt(0);
        for (int i = 0; i<mensaje.length(); i++){
            if(mensaje.charAt(i) == 'a' || mensaje.charAt(i) == 'e' || mensaje.charAt(i) == 'i' || mensaje.charAt(i) == 'o' || mensaje.charAt(i) == 'u'){
                nVocales++;
            }
        }
        javax.swing.JOptionPane.showMessageDialog(null,"La frase tiene un total de " + nVocales + " vocales.");
    }
}
