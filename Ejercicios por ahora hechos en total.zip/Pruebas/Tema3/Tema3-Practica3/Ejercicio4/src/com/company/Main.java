package com.company;

import javax.swing.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

    public static void main(String[] args) {
	// write your code here
        boolean error = false;
        do {

            try
            {
                String fechaString = JOptionPane.showInputDialog("Dame una fecha en formato dd/MM/yy");
                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yy");
                Date fechaUno = formato.parse(fechaString);

                fechaString = JOptionPane.showInputDialog("Dame otra fecha en el mismo formato");
                Date fechaDos = formato.parse(fechaString);

                long milisegundos = fechaUno.getTime() - fechaDos.getTime();

                long días = milisegundos/86400000;
                JOptionPane.showMessageDialog(null, "La diferencia entre " + fechaUno + " y " + fechaDos + " es de " + días + " días.");
                error = false;

            }
            catch(ParseException e)
            {
                JOptionPane.showMessageDialog(null, "Problemas con la fecha");
                error = true;
            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Problemas " + e.getClass());
            }
        }
        while (error);
    }
}
