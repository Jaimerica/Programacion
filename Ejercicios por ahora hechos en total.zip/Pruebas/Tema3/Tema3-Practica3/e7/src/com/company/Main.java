package com.company;

import javax.swing.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Main {

    /* Crear un programa que reciba dos fechas y que devuelva la cantidad
     de domingos comprendidos entre ambas fechas */

    public static void main(String[] args) {
        try
        {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy");
            String fechaString = JOptionPane.showInputDialog("Teclea una fecha dd/MM/yy");
            LocalDate fechaUno = LocalDate.parse(fechaString, formatter);

            fechaString = JOptionPane.showInputDialog("Teclea una fecha dd/MM/yy");
            LocalDate fechaDos = LocalDate.parse(fechaString, formatter);

            int contador = 0;
            while(fechaUno.isBefore(fechaDos))
            {
                if (fechaUno.getDayOfWeek()== DayOfWeek.SUNDAY)
                    contador++;
                fechaUno = fechaUno.plusDays(1);
            }
            JOptionPane.showMessageDialog(null, "Hay " + contador + " domingos");
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Problemas " + e.getClass());
        }
        // Solución dos: Buscar el primer domingo y luego ir sumando siete
    }
}
