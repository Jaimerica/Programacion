package com.company;

import javax.swing.*;

public class Main {

    private static int maximo = -1, minimo = 11;
    private static String nombreMax="",nombreMin="";
    public static void main(String[] args) {
	// write your code here
        for ( int contador = 0; contador <40; contador++)
        {
            String nombre = JOptionPane.showInputDialog("Teclea el nombre del alumno");
            int calificacion = Integer.parseInt(JOptionPane.showInputDialog("Teclea la calificación del alumno"));
            calcularMaxMin(calificacion,nombre);
        }

        JOptionPane.showMessageDialog(null,nombreMax + " es el alumno con la calificación más alta");
    }

    public static void calcularMaxMin(int calificacion,String nombre)
    {
        if (calificacion > maximo)
        {
            maximo = calificacion;
            nombreMax = nombre;

        }
        if (calificacion < minimo)
        {
            minimo =calificacion;
            nombreMin = nombre;
        }
    }
}
