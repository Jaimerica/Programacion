package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
int n1;
n1= Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Buenos días, le llamamos de la empresa de telefonía para que nos diga cuantos minutos ha usado para hacerla una oferta"));
        double Resultado;
if (n1<300){
    Resultado = n1*0.04;
    javax.swing.JOptionPane.showMessageDialog(null,Resultado);
}
else
if (n1>300 && n1<500)
{Resultado = n1*0.03;
        javax.swing.JOptionPane.showMessageDialog(null,Resultado);
}
else
    if (n1>500 && n1<800)
    {Resultado = (300*0.03)+((n1-300)*0.02);
    javax.swing.JOptionPane.showMessageDialog(null,Resultado);
}
else
    if (n1>800);
    {Resultado = ((300*0.03)+((n1-300)*0.02))-0.0125*((300*0.03)+((n1-300)*0.02));
    javax.swing.JOptionPane.showMessageDialog(null,Resultado);
}
    }
}
