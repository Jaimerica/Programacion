package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int nroGenerado = (int) (Math.random()*100);
        System.out.println(nroGenerado);

        int nro;
        String nroString = JOptionPane.showInputDialog(null,"Teclea un número");
        while (!nroString.equalsIgnoreCase("Fin"))
        {
            nro = Integer.parseInt(nroString);
            if (nro != nroGenerado)
            {
                if (nro < nroGenerado)
                    JOptionPane.showMessageDialog(null,"Inténtalo con un número más grande");
                else
                    JOptionPane.showMessageDialog(null,"Inténtalo con un número más pequeño");

                nroString = JOptionPane.showInputDialog("Teclea otro número o fin");

            }
            else
            {
                   nroString = "Fin";
                           JOptionPane.showMessageDialog(null,"Enhorabuena, has acertado");
            }
        }
    }
}
