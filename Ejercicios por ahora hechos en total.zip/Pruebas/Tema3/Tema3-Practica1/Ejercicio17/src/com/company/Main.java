package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n1 = 0, n2 = 1, n3, contador = 2;
        String serie = n1 +" "+ n2 +" ";

        int nroFinal = Integer.parseInt(JOptionPane.showInputDialog("¿Cuantos números quieres de la serie de Fibonacci?"));
        while (contador < nroFinal)
        {
            n3 = n1+n2;
            serie = serie + n3+ " ";
            contador++;
            n1 = n2;
            n2= n3;
        }
        JOptionPane.showMessageDialog(null, serie);
    }
}
