package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int nro = Integer.parseInt(JOptionPane.showInputDialog("Teclea un número"));
        if (nro < 3)
        {
            switch(nro) {
                case 1:
                    JOptionPane.showMessageDialog(null, "El número NO es primo");
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null,"El número SI es primo ");
                    break;
            }
        }
        else
            funcionPrimo(nro);
    }

    public static void funcionPrimo (int nro){
        int divisor = nro;
        int resto;
        do {
            divisor = divisor -1;
            resto = nro % divisor;
        }
        while (resto !=0 && divisor > 2);
        if (resto == 0)
        JOptionPane.showMessageDialog(null, "El número " + nro + " NO es un numero primo");
        else
            JOptionPane.showMessageDialog(null, "El numero " + nro + " SI es un número primo");
    }
}
