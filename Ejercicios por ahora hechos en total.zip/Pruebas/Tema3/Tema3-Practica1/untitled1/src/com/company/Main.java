package com.company;
import javax.swing.JOptionPane;
import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        // Comentarios de una línea
        /*Escribo el enunciado del
                programa
         */
        /**
         * Multilinea
         * Hola
         * Documentación
         */
        //definiendo variables
        int nro1;
        float nroDos;
        char letra;
        String nombreCliente;
        boolean si;
        int n1,n2,n3=6;
        long n4 = 0;
        byte n5=0, n6=10;
        float n7= 3.14f;
        double n8= 4.5;
        char c1='a';
        nombreCliente = "Nieves";
        boolean no=true;
        final float PI=3.14f;

        nombreCliente = javax.swing.JOptionPane.showInputDialog("Teclea tu nombre");
        n1= Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Teclea un número"));
        n4= Long.parseLong(javax.swing.JOptionPane.showInputDialog("Teclea un número"));
        n7= Float.parseFloat(javax.swing.JOptionPane.showInputDialog("Teclea un número"));
        //operaciones, si eso a buscar en Math
        n2 = ((n1 + 7) * 2)/n3;
        JOptionPane.showMessageDialog(null, "El resultado es : " + n2);




    }
}
