package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n1;
        n1 = Integer.parseInt(javax.swing.JOptionPane.showInputDialog("Dame la nota, entre el 0 y el 10"));
        if (n1<5)
            javax.swing.JOptionPane.showMessageDialog(null,"Has suspendido");
            else
            javax.swing.JOptionPane.showMessageDialog(null,"Has aprobado");
    }
}
