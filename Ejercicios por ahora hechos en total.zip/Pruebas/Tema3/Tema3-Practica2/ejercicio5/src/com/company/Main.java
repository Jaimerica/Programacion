package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        String numero = generarNumero();
        jugar(numero);
    }

    public static String generarNumero() {
        String numero;
        boolean correcto;
        do
        {
            Integer n1 = (int) (Math.random() * 1000);
            numero = String.valueOf(n1);
            correcto = comprobarDistintos(numero);
        }
        while (!correcto);

        System.out.println(numero);
        return numero;
    }

    public static String entrada() {
        boolean correcto = true;
        String numero = "";
        do {
            numero = JOptionPane.showInputDialog(null, "Teclea un número de tres cifras distintas.");

            if (numero.length() != 3)
                correcto = false;
            else
            {
                for (int x = 0; x < numero.length() && correcto; x++)
                {
                    if (!Character.isDigit(numero.charAt(x)))
                        correcto = false;
                }
                if (correcto)
                    correcto = comprobarDistintos(numero);
            }
        }
        while (!correcto);
        System.out.println("El número tecleado es: " + numero);
        return numero;
    }

    public static boolean comprobarDistintos(String n)
    {

        if (n.charAt(0) == n.charAt(1) || n.charAt(0) == n.charAt(2) || n.charAt(1) == n.charAt(2))
            return false;
        return true;


    }

    public static void jugar(String numero) {
        JOptionPane.showMessageDialog(null, "Empezamos a jugar");
        boolean continuar = true;
        do
        {
            String nro = entrada();

            if (nro.equals(numero))
            {
                continuar = false;
                JOptionPane.showMessageDialog(null, "ENHORABUENA");
            }
            else
            {
                String mensaje = buscarMuertos(nro, numero) + buscarHeridos(nro, numero);
                JOptionPane.showMessageDialog(null, mensaje);
            }
        }
        while (continuar);
    }

    public static String buscarMuertos(String nro, String numero)
    {
        int contador = 0;
        for (int x = 0; x < numero.length(); x++)
            if (nro.charAt(x) == numero.charAt(x))
                contador = contador + 1;
        return " Hay " + contador + " muertos \n";
    }

    public static String buscarHeridos(String nro, String numero)
    {
        int contador = 0;
        for (int x = 0; x < numero.length(); x++)
        {
            int y;
            for (y = 0; y < nro.length() && nro.charAt(y) != numero.charAt(x); y++) {}
            if (y != nro.length() && x != y)
                contador = contador + 1;

        }
        return " Hay " + contador + " heridos";
    }
}
