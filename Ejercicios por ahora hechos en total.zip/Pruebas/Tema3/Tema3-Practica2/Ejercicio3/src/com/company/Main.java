package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        char opc;
        do
        {
            opc = mostrarMenu();
            switch(opc){
                case '1':
                    funcionSumar();
                    break;
                case '2':
                    funcionRestar();
                    break;
                case '3':
                    funcionTabla();
                    break;
                case '4':
                    funcionDivision();
                    break;
            }
        }
        while(opc != '5');
    }

    public static char mostrarMenu()
    {
        char opc;
        do
        {
            opc =  JOptionPane.showInputDialog("1.- Sumaremos dos numeros \n"
                    + "2.- Vamos a restar dos numeros \n"
                    + "3.- Enseñar la tabla de multiplicar de un número \n"
                    + "4.- Mostrar el cociente y el resto de una división \n"
                    + "5.- [HUIR] del programa\n\n"
                    + "Seleccione un número").charAt(0);
        }
        while(opc < '1' || opc > '5');
        return opc;

    }

    public static int solicitarNumero()
    {
        return Integer.parseInt(JOptionPane.showInputDialog("Dame un número que sea entero"));
    }

    public static void funcionSumar()
    {
        int n1 = solicitarNumero();
        int n2 = solicitarNumero();
        JOptionPane.showMessageDialog(null," La solución de la suma es: " + (n1 + n2));
    }

    public static void funcionRestar()
    {
        int n1 = solicitarNumero();
        int n2 = solicitarNumero();
        JOptionPane.showMessageDialog(null," La respuesta a la resta es: " + (n1 - n2));
    }

    public static void funcionTabla()
    {
        String tabla="";
        int nro = solicitarNumero();
        for (int x = 0; x < 11; x++)
            tabla = tabla + nro + " x " + x + " = " + (nro * x) + "\n";
        JOptionPane.showMessageDialog(null, tabla);
    }

    public static void funcionDivision()
    {
        int n1 = solicitarNumero();
        int n2 = solicitarNumero();
        JOptionPane.showMessageDialog(null," El cociente es " + (n1 / n2) + " y el resto entonces será " + (n1 % n2));
    }

}

