package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        String nombreAlumno;
        String visual,javascript,java,sql;
        int respuesta=0;
        do
        {
            nombreAlumno = JOptionPane.showInputDialog("Teclea el nombre del alumno: ");
            sql = solicitarNota("sql");
            javascript = solicitarNota("cobol");
            java = solicitarNota("java");
            visual = solicitarNota("visual");

            String nota = proceso(visual,javascript,java,sql);

            JOptionPane.showMessageDialog(null,"La calificación de "+ nombreAlumno + " es de " + nota );

            respuesta = JOptionPane.showConfirmDialog(null, "Si quieres continuar haz click en el botón si");

        }
        while(respuesta == 0);

    }

    public static String proceso(String visual,String javascript, String java, String sql)
    {

        if (javascript.compareToIgnoreCase("apto")==0 && sql.compareToIgnoreCase("apto")==0)
        {
            if (visual.compareToIgnoreCase("apto")==0 && java.compareToIgnoreCase("apto")==0)
                return "un Sobresaliente";
            if (visual.compareToIgnoreCase("apto")==0 || java.compareToIgnoreCase("apto")==0)
                return "un Notable";
            return "un Bien";
        }
        else
        {
            if(sql.compareToIgnoreCase("apto")==0 || javascript.compareToIgnoreCase("apto")==0)
            {
                if(java.compareToIgnoreCase("apto")==0 || visual.compareToIgnoreCase("apto")==0)
                    return "un Suficiente";
                return "un Insuficiente";
            }
            else
                return "un Insuficiente";
        }
    }

    public static String solicitarNota(String nombreAsignatura){
        boolean correcto;
        String nota="";
        do
        {
            nota = JOptionPane.showInputDialog("Dígame si la calificacion de " + nombreAsignatura + " es [APTO] o [NO APTO]");
            if(!nota.equalsIgnoreCase("apto") && !nota.equalsIgnoreCase("no apto"))
                correcto = false;
            else
                correcto = true;
        }
        while(!correcto);
        return nota;
    }
}
