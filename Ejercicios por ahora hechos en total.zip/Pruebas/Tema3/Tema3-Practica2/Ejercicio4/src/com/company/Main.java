package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        // write your code here
        String Alumno;
        Alumno = JOptionPane.showInputDialog("Dime el nombre del estudiante");
        int n1 = solicitarNota();
        int n2 = solicitarNota();
        int n3 = solicitarNota();
        int n4 = solicitarNota();
        int n5 = solicitarNota();
        int n6 = solicitarNota();

        int media = (n1 + n2 + n3 + n4 + n5 + n6) / 6;
        JOptionPane.showMessageDialog(null, Alumno + " tiene una nota media de " + media);
    }


    public static int solicitarNota() {
    return Integer.parseInt(JOptionPane.showInputDialog("Dame la nota de una asignatura"));
    }
}