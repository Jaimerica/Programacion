package com.company;

import javax.swing.*;
import java.lang.reflect.Array;

public class Main {

    public static void main(String[] args) {
	// write your code here

        float[] Euros={(float) 0.01, (float) 0.02, (float) 0.05, (float) 0.1, (float) 0.2, 0.5F,1,2,5,10,20,50,100,200};
        float coste = Integer.parseInt(JOptionPane.showInputDialog("Precio que cuesta la compra"));
        float precio = Integer.parseInt(JOptionPane.showInputDialog("Cantidad que se le va a dar como valor y que tendría que dar un cambio"));
        float cambio = precio - coste;
        JOptionPane.showMessageDialog(null,cambio);


    }
}
