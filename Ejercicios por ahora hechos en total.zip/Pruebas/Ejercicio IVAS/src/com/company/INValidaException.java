package com.company;

public class INValidaException extends Exception{
}
