package com.company;

import javax.swing.*;
import java.time.LocalDate;

public class Main {
    private static int unidades,iva;
    private static float precio;

    private static final int SUPERREDUCIDO = 4;
    private static final int REDUCIDO = 10;
    private static final int NORMAL= 21;

    private static double totalNOIva;
    private static double total4=0,total10=0,total21=0;

    public static void main(String[] args) {
	// write your code here

    try
    {
        String nombre =JOptionPane.showInputDialog(null, "¿Cual es el nombre del cliente? Si no hay nadie más di fin");
        while (!nombre.equalsIgnoreCase("fin"))
        {
            String lineaPedido="";
            InicioTotales();

            do
            {
                solicitarProductos();
                lineaPedido += generarLinea();
            }
            while(JOptionPane.showConfirmDialog(null, "¿ Hay más productos?")==0);

            calcularTotales(nombre,lineaPedido);

            nombre =JOptionPane.showInputDialog(null, "Nombre del cliente o fin para finalizar");
        }
    }
    catch (NullPointerException e)
        {
            JOptionPane.showMessageDialog(null,"¿Cual es el nombre del cliente? Si no hay nadie más di fin");
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.print("Problemas: " + e.getClass() + "\n" + e.getMessage() );
        }
    }

    public static void InicioTotales()
    {
        totalNOIva = 0;
        total4 = 0;
        total10 = 0;
        total21= 0;
    }

    public static void solicitarProductos() throws Exception
    {
        solicitarUnidades();
        solicitarPrecio();
        solicitarIva();
    }

    public static String generarLinea() throws Exception
    {
        float totalLinea = unidades * precio;
        totalNOIva += totalLinea;

        gestionIva(totalLinea);

        return unidades + " x " + precio + " = " + totalLinea + "\n";
    }

    public static void calcularTotales(String nombre, String lineasPedido)
    {
        String factura = "NOMBRE: " +  nombre + "\n" +
                "FECHA: " + LocalDate.now() + "\n\n"+
                "LINEAS DEL PEDIDO" + "\n" +
                lineasPedido + "\n" +
                "TOTAL SIN IVA: " + totalNOIva + "\n\n" ;
        double totalIva = 0;
        double subtotal = 0;
        if (total4 != 0)
        {
            subtotal = total4 * SUPERREDUCIDO / 100;
            factura += SUPERREDUCIDO + "% de " + total4 + " = " + subtotal + "\n";
            totalIva += subtotal;
        }
        if (total10 != 0)
        {
            subtotal = total10 * REDUCIDO / 100;
            factura += REDUCIDO + "% de " + total10 + " = " + subtotal + "\n";
            totalIva += subtotal;
        }
        if (total21 != 0)
        {
            subtotal = total21 * NORMAL / 100;
            factura += NORMAL + "% de " + total21 + " = " + subtotal+ "\n";
            totalIva += subtotal;
        }

        factura += "TOTAL IVA: " + totalIva + "\n";
        factura += "\n\nTOTAL FACTURA " + (totalIva + totalNOIva);
        JOptionPane.showMessageDialog(null,factura );

    }

    public static void gestionIva(float total)
    {
        switch(iva)
        {
            case SUPERREDUCIDO:
                total4+=total;
                break;
            case REDUCIDO:
                total10+=total;
                break;
            case NORMAL:
                total21+=total;
                break;
        }
    }
    public static void solicitarUnidades() throws Exception
    {
        boolean correcto;
        do
        {
            try
            {
                unidades = Integer.parseInt(JOptionPane.showInputDialog(null, " Dame el número de unidades: "));
                if(unidades < 1)
                    throw new UNValidaException();
                correcto = true;
            }
            catch(NullPointerException e)
            {
                JOptionPane.showMessageDialog(null,"No se puede salir de la operación");
                correcto = false;
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null,"Es necesario un dato numérico, algo con valor");
                correcto = false;
            }
            catch(UNValidaException e)
            {
                JOptionPane.showMessageDialog(null,"Las unidades indicadas no son válidas, tiene que ser algo positivo");
                correcto = false;
            }

        }
        while (!correcto);

    }

    public static void solicitarPrecio() throws Exception
    {

        boolean correcto;
        do
        {
            try
            {
                precio = Float.parseFloat(JOptionPane.showInputDialog(null, " Cual es el precio unitario: "));
                if(precio <= 0)
                    throw new PNValidaException();
                correcto = true;
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null,"Es necesario un dato que sea un número");
                correcto = false;
            }
            catch(PNValidaException e)
            {
                JOptionPane.showMessageDialog(null,"El precio no puede ser menor o igual que cero, no hay nada gratis aquí");
                correcto = false;
            }
            catch(NullPointerException e)
            {
                JOptionPane.showMessageDialog(null,"No se puede salir de este ciclo comercial");
                correcto = false;
            }
        }
        while (!correcto);
    }

    public static void solicitarIva() throws Exception
    {
        boolean correcto;
        do
        {
            try
            {
                iva = Integer.parseInt(JOptionPane.showInputDialog(null, "% de IVA "));
                if (iva != SUPERREDUCIDO && iva!= REDUCIDO && iva != NORMAL)
                    throw new INValidaException();
                correcto = true;
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null,"Es necesario un dato que sean numeritos");
                correcto = false;
            }
            catch(INValidaException e)
            {
                JOptionPane.showMessageDialog(null,"El IVA según el Gobierno tiene que ser 4, 10 o 21");
                correcto = false;
            }
            catch(NullPointerException e)
            {
                JOptionPane.showMessageDialog(null,"No se puede salir de la burocracia de impuestos");
                correcto = false;
            }
        }
        while (!correcto);
    }
}
