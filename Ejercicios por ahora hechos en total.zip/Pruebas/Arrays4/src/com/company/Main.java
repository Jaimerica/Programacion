package com.company;

import javax.swing.*;

public class Main {
    private static int[] dias;
    private static int[] meses;
    private static int[] litros;

    public static void main(String[] args) {
	// write your code here
        try
        {
            int [] meses={1,2,3,4,5,6,7,8,9,10,11,12};
                   meses= new int[Integer.parseInt(JOptionPane.showInputDialog("Indica el més en número"))];
                   BusquedaDias();
                   Litrospordia();
                   Litrospormes();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Problemas: " + e.getMessage());
        }
    }
    public static void BusquedaDias()
    {
        int [] dias={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31};
                dias= new int[Integer.parseInt((JOptionPane.showInputDialog(("Indica el día de ese mes"))))];
    }
    public static void Litrospordia()
    {
        int [] litros;
        litros= new int[Integer.parseInt((JOptionPane.showInputDialog("La cantidad de litros de ese día")))];
    }
    public static void Litrospormes()
    {
        int Litromes;
    }
}
