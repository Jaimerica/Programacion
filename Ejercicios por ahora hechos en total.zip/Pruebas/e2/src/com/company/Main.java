package com.company;

import javax.swing.*;
import Excepciones.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Main {

    public static void main(String[] args)
    {
        try
        {
            char opcion;
            do
            {
                opcion = mostrarMenu(); // Mostrar menu y validar opción
                switch (opcion)
                {
                    case 'a': calcularEdad();
                        break;
                    case 'b': numeros();
                        break;
                    case 'c': palindromo();
                        break;
                }
            }
            while (opcion != 'd');
        }
        catch(Exception e)
        {
            // Problemas no identificados
            JOptionPane.showMessageDialog(null, " Problemas " + e.getClass());
        }

    }

    public static char mostrarMenu() throws Exception
    {
        char opcion=' ';
        boolean error;
        do
        {
            try
            {
                String opc = JOptionPane.showInputDialog(" a) Calcular edad \n"
                        + "b) Números pares y primos \n"
                        + "c) Palindromo \n"
                        + "d) Salir \n\n"
                        + "Selecciona una opción: ");

                // Validar opción
                if (opc.length()!=1)
                    throw new OpcionNoValidaException();

                // convierto en char y en minúsculas
                opcion = opc.toLowerCase().charAt(0);
                // valido contenido
                if (opcion != 'a' && opcion != 'b'&& opcion != 'c' && opcion != 'd')
                    throw new OpcionNoValidaException();

                error = false;
            }
            catch(OpcionNoValidaException e)
            {
                JOptionPane.showMessageDialog(null, "Opción no valida");
                error = true;
            }
            catch(NullPointerException e)
            {
                JOptionPane.showMessageDialog(null, "Para salir pulsa d");
                error = true;
            }
        }
        while(error);
        return opcion;

    }

    public static void calcularEdad() throws Exception
    {
        // Sin repetitiva, que vuelva a seleccionar la opción a en el menú si se ha equivocado
        try
        {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            String fechaString = JOptionPane.showInputDialog("Teclea tu fecha de nacimiento dd/MM/yyyy");
            LocalDate fechaNacimiento = LocalDate.parse(fechaString, formatter);

            LocalDate hoy = LocalDate.now();
            Period periodo = Period.between(fechaNacimiento, hoy);

            JOptionPane.showMessageDialog(null, "Tienes " + periodo.getYears()+ " años");

            // Dias que faltan para el cumpleaños.
            LocalDate fechaCumpleaños=LocalDate.of(hoy.getYear(),fechaNacimiento.getMonth(),fechaNacimiento.getDayOfMonth());
            if (hoy.isAfter(fechaCumpleaños))
            {
                // Este año ya ha sido el cumpleaños.
                fechaCumpleaños = fechaCumpleaños.plusYears(1);
            }
            periodo = Period.between(hoy,fechaCumpleaños);

            JOptionPane.showMessageDialog(null, "Faltan " + periodo.getMonths()+ " meses y " + periodo.getDays()+ " dias para tu cumpleaños");
        }
        catch(DateTimeParseException e)
        {
            // parse
            JOptionPane.showMessageDialog(null, "La fecha tecleada no es correcta");
        }
        catch(NullPointerException e)
        {
            // x 0 cancelar
            JOptionPane.showMessageDialog(null, "Para salir pulsa d");
        }
    }

    public static void numeros() throws Exception
    {
        try
        {
            int n1 = solicitarNumero(); // solicitar y validar
            int n2 = solicitarNumero();

            if ( n1 >= n2)
                throw new NumerosNoValidosException();

            String cadena=""; // string para guardar los datos de salida.

            for(int x = n1; x <= n2; x++)
            {
                if ((x % 2) == 0)
                    cadena+= x + " Es un número par \n";
                else
                    if (fprimo(x))
                        cadena += x + " Es un número primo \n";
                    else
                        cadena+= x + "\n";
            }
            JOptionPane.showMessageDialog(null, cadena);
        }
        catch(NumerosNoValidosException e)
        {
            JOptionPane.showMessageDialog(null, "El primer número debe ser más pequeño que el segundo");
        }

    }

    public static int solicitarNumero() throws Exception
    {
        boolean error;
        int n=0;
        do
        {  // Si no es un número correcto, lo vuelvo a pedir.
            try
            {
                n = Integer.parseInt(JOptionPane.showInputDialog("Teclea un número"));
                if (n < 0)
                    throw new NumerosNoValidosException();
                error = false;
            }
            catch(NumberFormatException | NullPointerException | NumerosNoValidosException e)
            {
                // En los dos casos quiero hacer lo mismo
                JOptionPane.showMessageDialog(null, "Teclea un número mayor o igual a cero.");
                error = true;
            }
        }
        while (error);
        return n;
    }

    public static boolean fprimo(int x) throws Exception
    {
        if (x == 1)
            return false;
        else
        {
            int divisor = x - 1;
            boolean primo = true;
            while (divisor > 2 && primo) {
                if ((x % divisor) == 0)
                    primo = false;
                divisor = divisor - 1;
            }
            return primo;
        }
    }

    public static void palindromo() throws Exception
    {
        boolean error;
        do
        { // si la cadena no es valida, la vuelvo a pedir sin volver al menu
            try
            {
                String cadena = JOptionPane.showInputDialog(null, "Teclea una cadena de caracteres").toLowerCase();
                if (cadena.isEmpty())
                    throw new CadenaNoValidaException();
                // busco números.
                int x;
                for(x = 0; x < cadena.length() && !Character.isDigit(cadena.charAt(x));x++){}
                if (x != cadena.length())
                    throw new CadenaNoValidaException();
                comprobarPalindromo(cadena);
                error = false;
            }
            catch(CadenaNoValidaException e)
            {
                JOptionPane.showMessageDialog(null, "La cadena no puede estar vacía ni contener números.");
                error = true;
            }
            catch(NullPointerException e)
            {
                JOptionPane.showMessageDialog(null, "Teclea una cadena");
                error = true;
            }
        }
        while (error);
    }

    public static void comprobarPalindromo(String cadena) throws Exception
    {
        /*
         palidromo: palabra o frase que se lee igual de izquierda a derecha que de derecha a izquierda
         ejemplos: ojo, radar, orejero, reconocer…
                    Somos o no somos, Isaac no ronca así, Sé verlas al revés, Amó la paloma, Anita lava la tina, Luz azul, Yo hago yoga hoy, Ana lava lana…
         */

        // Quitar blancos
        int x;
        String cadenaNueva = "";
        for(x = 0; x < cadena.length();x++)
            if (cadena.charAt(x) != ' ')
                cadenaNueva+=cadena.charAt(x);

        // necesito conocer el centro para dejar de comparar.
        int mitad = cadenaNueva.length() / 2;
        int y;
        for(x=0,y=cadenaNueva.length()-1; x < mitad && cadenaNueva.charAt(x) == cadenaNueva.charAt(y); x++,y--)
        { }
        if ( x == mitad)
            JOptionPane.showMessageDialog(null, " La cadena es un palindromo");
        else
            JOptionPane.showMessageDialog(null, " La cadena no es un palindromo");

        // Trabajando con StringBuilder tenemos un método reverse.
    }
}
