package Excepciones;

public class OpcionNoValidaException extends Exception{
}
