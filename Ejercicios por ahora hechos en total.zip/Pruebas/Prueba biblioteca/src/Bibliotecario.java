public class Bibliotecario {

    int ID_bibliotecario;
    String Nombre;
    String apellido;


    public void gestionar_prestamos()
    {
        System.out.println("prestamo solicitado");
    }

    public void ordenar_libros()
    {
        System.out.println("ordenando libros");
    }

    public void chequear_libros()
    {
        System.out.println("Chequeo buen estado libros");
    }

    public Bibliotecario(int ID_bibliotecario, String nombre, String apellido) {
        this.ID_bibliotecario = ID_bibliotecario;
        this.Nombre = nombre;
        this.apellido = apellido;
    }


}
