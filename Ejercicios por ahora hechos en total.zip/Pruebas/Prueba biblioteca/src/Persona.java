public class Persona {

    String Nombre;
    String Apellido;

    public String getNombre(){
        return Nombre;
    }

    public void setNombre(){

    }
}
