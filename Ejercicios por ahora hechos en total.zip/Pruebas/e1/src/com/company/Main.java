package com.company;

import javax.swing.*;
import Excepciones.*;

import java.time.LocalDate;

public class Main
{
    // Variables-constantes globales
    // Datos de entrada por producto
    private static int unidades,iva;
    private static float precio;

    // Tipos de iva
    private static final int SUPERREDUCIDO = 4;
    private static final int REDUCIDO = 10;
    private static final int NORMAL= 21;

    // Totales para la factura de un cliente
    private static double totalSinIva;
    private static double total4=0,total10=0,total21=0;

    public static void main(String[] args)
    {
        try
        {
            String nombre =JOptionPane.showInputDialog(null, "Nombre del cliente o fin para finalizar");
            // Repetitiva por cliente. Se tratan todos los productos que compra.
            while (!nombre.equalsIgnoreCase("fin"))
            {
                String lineasPedido="";
                inicializarTotales();
                // Repetitiva por producto
                do
                {
                    solicitarProductos(); // Pedir y validar los datos de entrada
                    lineasPedido += generarLinea(); // generar la línea de pedido y guardar en totales.
                }
                while(JOptionPane.showConfirmDialog(null, "¿ Hay más productos?")==0);

                calcularTotales(nombre,lineasPedido); // Calculo totales e imprimo factura

                // Siguiente cliente o fin
                nombre =JOptionPane.showInputDialog(null, "Nombre del cliente o fin para finalizar");
            }

        }
        catch(NullPointerException e)
        {
            // x o cancelar en el cuadro donde se solicita el nombre o fin
            JOptionPane.showMessageDialog(null,"Indica el nombre del cliente o fin para finalizar");
        }
        catch (Exception e)
        {
            // Problemas imprevistos.
            e.printStackTrace(); // Se utiliza para imprimir el registro del stack (pila) donde se ha iniciado la excepción.
            System.out.print("Problemas: " + e.getClass() + "\n" + e.getMessage() );
        }
    }

    public static void inicializarTotales()
    {
        // Inicializar los variables que afectan a la factura de un cliente. Ojo que son variables globales.
        totalSinIva = 0;
        total4 = 0;
        total10 = 0;
        total21= 0;
    }

    public static void solicitarProductos() throws Exception
    {
        solicitarUnidades();
        solicitarPrecio();
        solicitarIva();
    }

    public static void solicitarUnidades() throws Exception
    {
        // solicitar unidades
        boolean correcto;
        do
        {
            try
            {
                unidades = Integer.parseInt(JOptionPane.showInputDialog(null, "Número de unidades: "));
                if(unidades < 1)
                    throw new UnidadesNoValidasException();
                correcto = true;
            }
            catch(NullPointerException e)
            {
                // x o cancelar
                JOptionPane.showMessageDialog(null,"No se puede salir");
                correcto = false;
            }
            catch(NumberFormatException e)
            {
                // Integer.parse
                JOptionPane.showMessageDialog(null,"Es necesario un dato numérico");
                correcto = false;
            }
            catch(UnidadesNoValidasException e)
            {
                // < 1
                JOptionPane.showMessageDialog(null,"Las unidades indicadas no son válidas");
                correcto = false;
            }
            // Cualquier otra excepción es relanzada al main.

        }
        while (!correcto);

    }

    public static void solicitarPrecio() throws Exception
    {
        // solicitar y validar el precio unitario del producto.
        boolean correcto;
        do
        {
            try
            {
                precio = Float.parseFloat(JOptionPane.showInputDialog(null, "Precio unitario: "));
                if(precio <= 0)
                    throw new PrecioNoValidoException();
                correcto = true;
            }
            catch(NumberFormatException e)
            {
                // parseFloat
                JOptionPane.showMessageDialog(null,"Es necesario un dato numérico");
                correcto = false;
            }
            catch(PrecioNoValidoException e)
            {
                // <= 0
                JOptionPane.showMessageDialog(null,"El precio no puede ser menor o igual que cero");
                correcto = false;
            }
            catch(NullPointerException e)
            {
                // x o cancelar
                JOptionPane.showMessageDialog(null,"No se puede salir");
                correcto = false;
            }
            // Cualquier otra excepción es relanzada.
        }
        while (!correcto);
    }

    public static void solicitarIva() throws Exception
    {
        // Solicitar y validar el iva del producto
        boolean correcto;
        do
        {
            try
            {
                iva = Integer.parseInt(JOptionPane.showInputDialog(null, "% de IVA "));
                if (iva != SUPERREDUCIDO && iva!= REDUCIDO && iva != NORMAL)
                    throw new IvaNoValidoException();
                correcto = true;
            }
            catch(NumberFormatException e)
            {
                // parseInt
                JOptionPane.showMessageDialog(null,"Es necesario un dato numérico");
                correcto = false;
            }
            catch(IvaNoValidoException e)
            {
                // no es superreducido ni reducido ni normal
                JOptionPane.showMessageDialog(null,"El iva tiene que ser 4, 10 o 21");
                correcto = false;
            }
            catch(NullPointerException e)
            {
                // x 0 cancelar
                JOptionPane.showMessageDialog(null,"No se puede salir");
                correcto = false;
            }
            // Cualquier otra excepción se relanza
        }
        while (!correcto);
    }

    public static String generarLinea() throws Exception
    {
        // Aqui se genera la línea de detalle de la factura.
        float totalLinea = unidades * precio;
        // guardo para luego totales
        totalSinIva += totalLinea;

        gestionIva(totalLinea);

        return unidades + " x " + precio + " = " + totalLinea + "\n"; // concat, append, ...
    }

    public static void calcularTotales(String nombre, String lineasPedido)
    {
        // generar factura, mostrarla y calcular sus totales.
        String factura = "NOMBRE: " +  nombre + "\n" +
                "FECHA: " + LocalDate.now() + "\n\n"+
                "LINEAS DEL PEDIDO" + "\n" +
                lineasPedido + "\n" +
                "TOTAL SIN IVA: " + totalSinIva + "\n\n" ; // lo de la fecha no estaba en el enunciado
        double totalIva = 0;
        double subtotal = 0;
        if (total4 != 0)
        {
            subtotal = total4 * SUPERREDUCIDO / 100;
            factura += SUPERREDUCIDO + "% de " + total4 + " = " + subtotal + "\n";
            totalIva += subtotal;
        }
        if (total10 != 0)
        {
            subtotal = total10 * REDUCIDO / 100;
            factura += REDUCIDO + "% de " + total10 + " = " + subtotal + "\n";
            totalIva += subtotal;
        }
        if (total21 != 0)
        {
            subtotal = total21 * NORMAL / 100;
            factura += NORMAL + "% de " + total21 + " = " + subtotal+ "\n";
            totalIva += subtotal;
        }

        factura += "TOTAL IVA: " + totalIva + "\n";
        factura += "\n\nTOTAL FACTURA " + (totalIva + totalSinIva);
        JOptionPane.showMessageDialog(null,factura );

    }

    public static void gestionIva(float total)
    {
        // se suma el importe al total que depende del iva.
        switch(iva)
        {
            case SUPERREDUCIDO:
                total4+=total;
                break;
            case REDUCIDO:
                total10+=total;
                break;
            case NORMAL:
                total21+=total;
                break;
        }
    }

}
