package Modelo;

import java.time.LocalDate;
import java.time.LocalTime;

public class Evento {
    private String nombre;
    private String lugar;
    private LocalDate fecha;
    private LocalTime Fechainicio;
    private LocalTime Fechafinal;
    private int NumPersonas;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalTime getFechainicio() {
        return Fechainicio;
    }

    public void setFechainicio(LocalTime fechainicio) {
        Fechainicio = fechainicio;
    }

    public LocalTime getFechafinal() {
        return Fechafinal;
    }

    public void setFechafinal(LocalTime fechafinal) {
        Fechafinal = fechafinal;
    }

    public int getNumPersonas() {
        return NumPersonas;
    }

    public void setNumPersonas(int numPersonas) {
        NumPersonas = numPersonas;
    }
}
