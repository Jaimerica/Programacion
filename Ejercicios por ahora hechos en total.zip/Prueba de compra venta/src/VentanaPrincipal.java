import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal {
    private JButton bCompras;
    private JButton bVentas;
    private JPanel pPrincipal;
    private JButton BSalir;

    public VentanaPrincipal() {
        bCompras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.comprar();
            }
        });
        bVentas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.vender();
            }
        });
        BSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,Main.getDatos());
                System.exit(0);
            }
        });
    }

    public static void main(String[] args) {

    }

    public JPanel getpPrincipal() {
        return pPrincipal;
    }
}
