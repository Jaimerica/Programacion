package Modelo;

public class Proveedor {
    private String nombre;
    // no es necesaria la bidireccionalidad
    public Proveedor() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
