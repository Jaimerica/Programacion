package Vista;

import javax.swing.*;

public class Menu {
    private JTextPane PanelOpcion;
    private JLabel Elegir;
    private JLabel Registro;
    private JLabel ConsultaDatos;
    private JLabel ConsultaPersona;
    private JLabel Salida;
    private JLabel OpcionElegida;
    private JPanel Pantalla;


    public JPanel getPantalla() {
        return Pantalla;
    }

    public void setPantalla(JPanel pantalla) {
        Pantalla = pantalla;
    }

    public JTextPane getPanelOpcion() {
        return PanelOpcion;
    }

    public void setPanelOpcion(JTextPane panelOpcion) {
        PanelOpcion = panelOpcion;
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Menu");
        frame.setContentPane(new Menu().Pantalla);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

}
