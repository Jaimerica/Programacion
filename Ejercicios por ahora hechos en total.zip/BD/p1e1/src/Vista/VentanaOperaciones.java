package Vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.company.Main;

public class VentanaOperaciones extends JFrame{
    private JPanel pPrincipal;
    private JPanel pBotones1;
    private JPanel pCajas;
    private JPanel pBotones2;
    private JTextField tfNombre;
    private JTextField tfEdad;
    private JTextField tfProfesion;
    private JTextField tfTelefono;
    private JButton bAnterior;
    private JButton bSiguiente;
    private JButton bSalir;
    private JButton bAceptar;

    private int opcion;

    public VentanaOperaciones(int o) {
        opcion = o;
        if (opcion != 3) {
            visualizarpBotones1(false);
            visualizarpBotones2(true);
        }
        else
        {
            visualizarpBotones1(true);
            visualizarpBotones2(false);

        }

        bAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Si se ve el botón aceptar, opción es 1 (insert)  o 2 (han visto los datos de una persona).
                try {
                    if (opcion == 1) {
                        // alta de persona
                        if (validarDatos())
                            Main.getDatos(tfNombre.getText(), tfEdad.getText(), tfProfesion.getText(), tfTelefono.getText());
                    }
                    else
                        Main.volverMenu();

                }
                catch(Exception ex)
                {
                    if (opcion == 1)
                        JOptionPane.showMessageDialog(null, "Problemas insertando \n" + ex.getMessage());
                    else
                        JOptionPane.showMessageDialog(null, "Problemas consultado los datos de una persona \n" + ex.getMessage());
                }
            }
        });
        tfNombre.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                super.focusLost(e);
                if (opcion == 2)
                {
                    try {
                        validarNombre();
                        Main.getNombre(tfNombre.getText());
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(null, ex.getMessage());
                    }
                }
            }
        });
        bAnterior.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try
                {
                    Main.getAnterior();
                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
        bSiguiente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try
                {
                    Main.getSiguiente();
                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
        bSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.volverMenu();
            }
        });
    }

    public boolean validarDatos()
    {
        try
        {
           validarNombre(); // saco esta validación para reutilizarla en el caso de consulta

            if (tfEdad.getText().isEmpty())
                throw new Exception(" La edad es un dato obligatorio");
            if (tfProfesion.getText().isEmpty())
                throw new Exception(" La profesión es un dato obligatorio");
            if (tfTelefono.getText().isEmpty())
                throw new Exception(" El teléfono es un dato obligatorio");

            Pattern patron = Pattern.compile("^[0-9]{1,3}$");
            Matcher mat = patron.matcher(tfEdad.getText());
            if (!mat.matches())
                throw new Exception(" La edad no tiene un formato adecuado");

            patron = Pattern.compile("^[A-Z][a-z ]*$");
            mat = patron.matcher(tfProfesion.getText());
            if (!mat.matches())
                throw new Exception(" La profesión no tiene un formato adecuado");

            patron = Pattern.compile("^[6789][0-9]{8}$");
            mat = patron.matcher(tfTelefono.getText());
            if (!mat.matches())
                throw new Exception(" El teléfono no tiene un formato adecuado");

            return true;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Problemas validando \n"+ e.getMessage());
            return false;
        }
    }

    public void validarNombre() throws Exception{
        if (tfNombre.getText().isEmpty())
            throw new Exception(" El nombre es un dato obligatorio");
        Pattern patron = Pattern.compile("^[A-Z][a-z ]{2,}([A-Z][a-z ]{2,})*$");
        Matcher mat = patron.matcher(tfNombre.getText());
        if (!mat.matches())
            throw new Exception(" El nombre no tiene un formato adecuado");
    }

    public JPanel getpPrincipal() {
        return pPrincipal;
    }

    public void setDatosPersona(Integer e,String p,String t)
    {
        tfEdad.setText(e.toString());
        tfProfesion.setText(p);
        tfTelefono.setText(t);
        // Deshabilitar para que no modifique??
        bAceptar.requestFocus();

    }

    public void setDatosPersona(String n,Integer e,String p,String t)
    {
        tfNombre.setText(n);
        tfEdad.setText(e.toString());
        tfProfesion.setText(p);
        tfTelefono.setText(t);
        // Deshabilitar para que no modifique??
        bSiguiente.requestFocus();
    }


    public void visualizarpBotones1(boolean b)
    {
        pBotones1.setVisible(b);
    }

    public void visualizarpBotones2(boolean b)
    {
        pBotones2.setVisible(b);
    }

}
