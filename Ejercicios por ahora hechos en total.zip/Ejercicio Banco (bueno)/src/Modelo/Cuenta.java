package Modelo;

import java.util.ArrayList;

public class Cuenta {
    private String numero;

    private ArrayList<Movimiento> listaMovimientos;

    public Cuenta(String numero) {
        this.numero = numero;
        listaMovimientos = new ArrayList();
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public ArrayList<Movimiento> getListaMovimientos() {
        return listaMovimientos;
    }

    public void setListaMovimientos(ArrayList<Movimiento> listaMovimientos) {
        this.listaMovimientos = listaMovimientos;
    }

    public void setMovimiento(Movimiento m){
        listaMovimientos.add(m);
    }

    public Movimiento getMovimiento(int x)
    {
        return listaMovimientos.get(x);
    }

    public Double getSaldo(){
        Double saldo=0.0;

        for(int x = 0;x < listaMovimientos.size() ; x++)
            saldo+=listaMovimientos.get(x).getImporte();

        return saldo;

        /*
           En teoría, los campos calculados no se guardan pero los movimientos que puede tener una cuenta son muchos,
           Deberíamos tener en cuenta la posibilidad de que saldo fuera un atributo más de cuenta.
        */
    }
}
