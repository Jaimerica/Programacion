package com.company;

import Modelo.*;
import Vista.*;
import org.apache.commons.codec.digest.DigestUtils;

import javax.swing.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class Main {

    private static ArrayList<Cliente> listaClientes;
    private static Cliente cliente;
    private static Cuenta cuenta;

    private static JFrame vp;
    private static JFrame vo;

    private static boolean masCincoMovimientos;

    public static void main(String[] args) {
        try
        {
            generarDatos();
            mostrarVentana();
        }
        catch(Exception e)
        {
            System.out.println("Problemas en el main " + e.getClass() );
        }

    }

    public static void generarDatos()
    {
        // lista de todos los clientes de la entidad bancaria
        listaClientes = new ArrayList();

        // Cliente
        String claveSinEncriptar="012345";

        // Descargar la librería http://commons.apache.org/proper/commons-codec/download_codec.cgi
        String claveEncriptadaConMD5= DigestUtils.md5Hex(claveSinEncriptar);
        System.out.println(claveEncriptadaConMD5);

        Cliente p = new Cliente("11111111A","Pepe Ruiz",claveEncriptadaConMD5);

        // Cuentas de una cliente
        ArrayList<Cuenta> listaCuentas = new ArrayList();

        // Primera cuenta
        Cuenta c = new Cuenta("0101010101");

        // Movimiento uno de la primera cuenta
        Movimiento m = new Movimiento(LocalDate.now(),"Ingreso",10000f);
        // Se añade a la cuenta
        c.setMovimiento(m);

        // Movimiento dos de la primera cuenta
        m = new Movimiento(LocalDate.now(),"Reintegro cajero",-50f);
        c.setMovimiento(m);

        // Movimiento tres de la primera cuenta
        m = new Movimiento(LocalDate.now(),"Pago recibo",-17.5f);
        c.setMovimiento(m);

        // Movimiento cuatro de la primera cuenta
        m = new Movimiento(LocalDate.now(),"Pago recibo cuatro",-17.5f);
        c.setMovimiento(m);

        // Movimiento cinco de la primera cuenta
        m = new Movimiento(LocalDate.now(),"Pago recibo cinco",-17.5f);
        c.setMovimiento(m);

        // Movimiento seis de la primera cuenta
        m = new Movimiento(LocalDate.now(),"Pago recibo seis",-17.5f);
        c.setMovimiento(m);

        // Se añade la cuenta a la lista de cuentas de Pepe Ruiz
        listaCuentas.add(c);

        // Segunda cuenta de pepe
        c = new Cuenta("0101010102");

        m = new Movimiento(LocalDate.now(),"Ingreso",500f);
        c.setMovimiento(m);

        m = new Movimiento(LocalDate.now(),"Reintegro cajero",-50f);
        c.setMovimiento(m);

        m = new Movimiento(LocalDate.now(),"Pago recibo",-17.5f);
        c.setMovimiento(m);

        // Se añade la cuenta a la lista de cuentas de Pepe Ruiz
        listaCuentas.add(c);

        // Por último, se añade a Pepe la lista con todas sus cuentas.
        p.setListaCuentas(listaCuentas);

        // Añado Pepe a la lista de personas de la entidad bancaria.
        listaClientes.add(p);


        // Segunda cliente
        claveSinEncriptar="543210";
        claveEncriptadaConMD5=DigestUtils.md5Hex(claveSinEncriptar);
        p = new Cliente("22222222B","Imanol Rodriguez",claveEncriptadaConMD5);

        listaCuentas = new ArrayList();

        // Su primera cuenta
        c = new Cuenta("0202020202");

        m = new Movimiento(LocalDate.now(),"Ingreso",1000f);
        c.setMovimiento(m);

        m = new Movimiento(LocalDate.now(),"Pago recibo",-17.5f);
        c.setMovimiento(m);

        // Lista de cuentas de imanol
        listaCuentas.add(c);

        // Segunda cuenta de Imanol
        c = new Cuenta("0303030303");

        m = new Movimiento(LocalDate.now(),"Ingreso",100f);
        c.setMovimiento(m);

        m = new Movimiento(LocalDate.now(),"Ingreso",200f);
        c.setMovimiento(m);

        listaCuentas.add(c);

        p.setListaCuentas(listaCuentas);

        listaClientes.add(p);

    }

    public static void mostrarVentana()
    {
        vp = new JFrame("VentanaPrincipal");
        vp.setContentPane(new VentanaPrincipal().getpPrincipal());
        vp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       // vp.setSize(700,700);
        vp.setLocationRelativeTo(null);
        vp.pack();
        vp.setVisible(true);
    }

    public static void mostrarAcceso()
    {
        jdAcceso dialog = new jdAcceso();
        dialog.pack();
        dialog.setVisible(true);
    }

    public static void mostrarVentanaOperaciones()
    {
        vo = new JFrame("VentanaOperaciones");
        vo.setContentPane(new VentanaOperaciones().getpPrincipal());
        vo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        vo.setExtendedState(JFrame.MAXIMIZED_BOTH);
        vo.pack();
        vo.setVisible(true);

        vp.dispose();
    }

    public static boolean buscarCliente(String dni, String clave)
    {
        boolean encontrado = false;
        for(int x = 0; x < listaClientes.size() && !encontrado; x++)
        {
            if (listaClientes.get(x).getDni().compareTo(dni)==0)
            {
                encontrado = true;
                cliente = listaClientes.get(x);
            }
        }
        if (encontrado)
        {
            String claveEncriptada=DigestUtils.md5Hex(clave);
            return claveEncriptada.equals(cliente.getClave());
        }
        return encontrado;
    }

    public static String[] getCuentas()
    {
        String[] aCuentas = new String[cliente.getNumeroCuentas()];
        for(int x=0; x < aCuentas.length; x++)
        {
            aCuentas[x] = cliente.getCuenta(x).getNumero();
        }
        return aCuentas;
    }

    public static void setCuenta(int x)
    {
        // cuenta de la que hay que mostrar movimientos.
        cuenta = cliente.getListaCuentas().get(x);
    }

    public static int getNumeroMovimientos()
    {
        masCincoMovimientos = cuenta.getListaMovimientos().size() > 5;
        if (masCincoMovimientos)
            return 5;

        return cuenta.getListaMovimientos().size();
    }

    public static String getFechaMovimiento(int x)
    {
        if (masCincoMovimientos) {
            int posicion = cuenta.getListaMovimientos().size() - 5 + x;
            return cuenta.getMovimiento(posicion).getFecha().toString();
        }

        return cuenta.getMovimiento(x).getFecha().toString();
    }

    public static String getImporteMovimiento(int x)
    {
        if (masCincoMovimientos) {
            int posicion = cuenta.getListaMovimientos().size() - 5 + x;
            return cuenta.getMovimiento(posicion).getImporte().toString();
        }

        return cuenta.getMovimiento(x).getImporte().toString();
    }

    public static String getDescripcionMovimiento(int x)
    {
        if (masCincoMovimientos) {
            int posicion = cuenta.getListaMovimientos().size() - 5 + x;
            return cuenta.getMovimiento(posicion).getDescripcion().toString();
        }

        return cuenta.getMovimiento(x).getDescripcion().toString();
    }

    public static String getSaldo()
    {
        return cuenta.getSaldo().toString();
    }

    public static void registrarMovimiento(int tipo, String c, String importe)
    {
        String desc;
        if (tipo == 0)
            desc = "Transferemacia " + c;
        else
            desc = "Recibo " + c;

        Movimiento m = new Movimiento(LocalDate.now(),desc,Float.parseFloat(importe));
        cuenta.setMovimiento(m);
    }
}
