package Vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.company.Main;

public class VentanaOperaciones {
    private JPanel pPrincipal;
    private JPanel pMenu;
    private JMenuBar bMenu;
    private JPanel pBarra;
    private JButton bConsulta;
    private JButton bMovimientos;
    private JPanel pCuentas;
    private JPanel pMovimientosConsulta;
    private JMenu mCuentas;
    private JMenuItem miConsulta;
    private JMenu mResumen;
    private JMenu mTarjetas;
    private JMenu mInversiones;
    private JMenu mMercados;
    private JMenu mPrestamos;
    private JMenu mSeguros;
    private JMenu mServicios;
    private JMenuItem miMovimientos;
    private JLabel lFechaMov1;
    private JLabel lSaldo;
    private JLabel lValorSaldo;
    private JLabel lFechaMov2;
    private JLabel lFechaMov3;
    private JLabel lFechaMov4;
    private JLabel lFechaMov5;
    private JLabel lDesMov1;
    private JLabel lDesMov2;
    private JLabel lDesMov3;
    private JLabel lDesMov4;
    private JLabel lDesMov5;
    private JLabel lImpMov1;
    private JLabel lImpMov2;
    private JLabel lImpMov3;
    private JLabel lImpMov4;
    private JLabel lImpMov5;
    private JPanel pHacerMovimiento;
    private JComboBox cbTipo;
    private JTextField tfCuenta;
    private JTextField tfImporte;
    private JButton bAceptar;
    private JLabel lCuentaRecibo;

    private ArrayList<JRadioButton> aRadios; // para mostrar las cuentas
    private boolean consulta;

    public static void main(String[] args) {
        JFrame frame = new JFrame("VentanaOperaciones");
        frame.setContentPane(new VentanaOperaciones().pPrincipal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getpPrincipal() {
        return pPrincipal;
    }

    public VentanaOperaciones() {
        pCuentas.setVisible(false);
        //lSaldo.setVisible(false);
        pMovimientosConsulta.setVisible(false);
        pHacerMovimiento.setVisible(false);

        miConsulta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //mostrarCuentas();
                bConsulta.doClick();
            }
        });
        bConsulta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consulta = true;
                mostrarCuentas();
            }
        });

        miMovimientos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bMovimientos.doClick();
            }
        });
        bMovimientos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consulta = false;
                //movimientos();
                mostrarCuentas();
            }
        });
        cbTipo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (cbTipo.getSelectedIndex()== 1)
                    lCuentaRecibo.setText("Recibo");
                else
                    lCuentaRecibo.setText("Cuenta destino");
            }
        });
        bAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean correcto;
                if (cbTipo.getSelectedIndex()== 1)
                    // pago de un recibo
                    correcto = validarReferencia();
                else
                    // Transferencia
                    correcto = validarNumeroCuenta();
                if (correcto)
                    correcto = validarImporte();
                if (correcto)
                    registrarMovimiento();
            }
        });
    }


    public boolean validarNumeroCuenta()
    {
        // Solo voy a validar que sean 10 dígitos numéricos pero es más complejo
        // https://www.helpmycash.com/cuentas/digitos-cuenta-bancaria/
        try
        {
            Pattern p = Pattern.compile("^[0-9]{10}$");
            Matcher m = p.matcher(tfCuenta.getText());
            if (! m.matches())
                throw new Exception("Número de cuenta destino no valido");
            return true;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
            return false;
        }
    }

    public boolean validarImporte()
    {
        try
        {
            float i = Float.parseFloat(tfImporte.getText());
            // quiero un número negativo
            if (i >= 0  || (Float.parseFloat(Main.getSaldo()) + i) < 0)
                throw new Exception("Importe no valido o no hay saldo.");
            return true;
        }
        catch(NumberFormatException e)
        {
            JOptionPane.showMessageDialog(null,"El importe es un dato numérico");
            return false;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage() + e.getClass());
            return false;
        }
    }

    public boolean validarReferencia()
    {
        try
        {
            Pattern p = Pattern.compile("^[0-9]{8}[-][A-Z]{2}$");
            Matcher m = p.matcher(tfCuenta.getText());
            if (! m.matches())
                throw new Exception("Referencia de recibo no valida");
            return true;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
            return false;
        }
    }

    public void registrarMovimiento()
    {
        Main.registrarMovimiento(cbTipo.getSelectedIndex(),tfCuenta.getText(),tfImporte.getText());

        int opc = JOptionPane.showConfirmDialog(null,"Movimiento realizado ¿Deseas hacer más movimientos?");
        if (opc == 0)
            limpiarHacerMovimiento();
        else {
            pHacerMovimiento.setVisible(false);
            pCuentas.setVisible(false);
            // Vuelvo a ver solo el menú y la barra de herramientas.
        }
    }

    public void limpiarHacerMovimiento()
    {
        tfCuenta.setText("");
        tfImporte.setText("");
        cbTipo.requestFocus();
    }

    public void movimientos()
    {
        // De qué cuenta?
        int x;
        for (x = 0; x < aRadios.size() && !aRadios.get(x).isSelected(); x++) {}

        Main.setCuenta(x);

        pMovimientosConsulta.setVisible(false);
        pHacerMovimiento.setVisible(true);
    }

    public void mostrarCuentas() {
        // mostrar en forma de radios las cuentas del cliente.
        // componentes creados con código.

        // Vacio por si acaso
        pCuentas.removeAll();
        pMovimientosConsulta.setVisible(false);

        // solicitar al main los numeros de cuenta.
        String[] aCuentas = Main.getCuentas();

        aRadios = new ArrayList();
        ButtonGroup grupo = new ButtonGroup();

        // creación de los radios
        for (int x = 0; x < aCuentas.length; x++) {
            JRadioButton r = new JRadioButton(aCuentas[x]);
            aRadios.add(r);
            grupo.add(r);

            r.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (consulta)
                         mostrarMovimientos();
                    else
                        movimientos();
                }
            });

            pCuentas.add(r);
        }

        pCuentas.updateUI();
        pCuentas.setVisible(true);
    }


    public void mostrarMovimientos() {
        // mostrar los últimos cinco movimientos.
        // componentes creados en diseño.

        pMovimientosConsulta.setVisible(true);

        // De qué cuenta? Qué radio han seleccionado?
        int x;
        for (x = 0; x < aRadios.size() && !aRadios.get(x).isSelected(); x++) {}

        Main.setCuenta(x);

        JLabel[] aFechas = {lFechaMov1, lFechaMov2, lFechaMov3, lFechaMov4, lFechaMov5};
        JLabel[] aImportes = {lImpMov1, lImpMov2, lImpMov3, lImpMov4, lImpMov5};
        JLabel[] aDescripciones = {lDesMov1, lDesMov2, lDesMov3, lDesMov4, lDesMov5};

        // limpiar por si acaso.
        for(x = 0; x < 5; x++)
        {
            aFechas[x].setText("");
            aImportes[x].setText("");
            aDescripciones[x].setText("");
        }
        lValorSaldo.setText("");


        // LLenar
        for (x = 0; x < Main.getNumeroMovimientos(); x++) {
            aFechas[x].setText(Main.getFechaMovimiento(x));
            aImportes[x].setText(Main.getImporteMovimiento(x));
            aDescripciones[x].setText(Main.getDescripcionMovimiento(x));
        }

        lValorSaldo.setText(Main.getSaldo());
    }
}
