package Vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.company.Main;

public class jdAcceso extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton bEntrar;
    private JPanel pEntrar;
    private JPanel pContenido;
    private JPanel pClave;
    private JPanel pBotones;
    private JTextField tfDni;
    private JLabel lNif;
    private JLabel lTexto;
    private JButton b1;
    private JButton b6;
    private JButton b4;
    private JButton b10;
    private JButton b2;
    private JButton b7;
    private JButton b3;
    private JButton b8;
    private JButton b9;
    private JButton b5;
    private JPasswordField tfClave;

    public jdAcceso() {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);
        setLocationRelativeTo(null);

        generarNumeros();

        // En vez de 10 métodos --- ???
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b1.getText());
            }
        });

        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b2.getText());
            }
        });

        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b3.getText());
            }
        });

        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b4.getText());
            }
        });

        b5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b5.getText());
            }
        });

        b6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b6.getText());
            }
        });

        b7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b7.getText());
            }
        });

        b8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b8.getText());
            }
        });

        b9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b9.getText());
            }
        });

        b10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tfClave.getText().length() < 6)
                    añadirNumero(b10.getText());
            }
        });
        bEntrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try
                {
                    //validarDni();
                    if (!Main.buscarCliente(tfDni.getText(),tfClave.getText().toString())) // con getPassword no funciona
                        throw new Exception("Identificación incorrecta");
                    Main.mostrarVentanaOperaciones();
                    dispose();
                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }
            }
        });
    }

    public void generarNumeros()
    {
        // array o arrayList que contendrá los números del 0 al 9 generados de forma aleatoria
        ArrayList<Integer> numerosAleatorios = new ArrayList();
        int posicion = 0;
        do
        {
            int numeroAleatorio = (int) (Math.random()*10);
            // Repetido?
            if (!numerosAleatorios.contains(numeroAleatorio)){
                numerosAleatorios.add(numeroAleatorio);
                posicion++;
            }
        }
        while(posicion != 10);

        JButton[] aBotones = {b1,b2,b3,b4,b5,b6,b7,b8,b9,b10};
        for(int x = 0; x < numerosAleatorios.size();x++)
            aBotones[x].setText(numerosAleatorios.get(x).toString());
    }

    public void añadirNumero(String n)
    {
        tfClave.setText(tfClave.getText() + n);
    }

    public void validarDni() throws Exception
    {
        Pattern p = Pattern.compile("^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]$");
        Matcher m = p.matcher(tfDni.getText());
        if (!m.matches())
            throw new Exception("Formato de dni no correcto");

        char caracteres[] = {'T','R','W','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
        int dni = Integer.parseInt(tfDni.getText().substring(0,8));
        int resto = dni%23;
        if (caracteres[resto] != tfDni.getText().charAt(8))
            throw new Exception("Letra incorrecta");
    }

    public static void main(String[] args) {
        jdAcceso dialog = new jdAcceso();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
}
