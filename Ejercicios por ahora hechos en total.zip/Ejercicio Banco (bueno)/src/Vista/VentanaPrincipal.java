package Vista;

import com.company.Main;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal {
    private JPanel pBoton;
    private JPanel pImagen;
    private JPanel pPrincipal;
    private JButton bAcceso;
    private JLabel lEntidad;
    private JButton bImagen;

    public VentanaPrincipal() {
        bAcceso.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.mostrarAcceso();
            }
        });
    }


    public JPanel getpPrincipal() {
        return pPrincipal;
    }
}
