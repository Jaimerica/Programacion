package Modelo;

public class Persona {
    private String Nombre;
    private String Apellido;
    private int Edad;
}
