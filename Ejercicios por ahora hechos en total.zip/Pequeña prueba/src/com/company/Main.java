package com.company;
import Vista.*;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        JFrame frame = new JFrame("Inicio");
        frame.setContentPane(new Inicio().getPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public static void MostrarConfirmacion() {
        String[] botones = {"Si, son correctos","No, son falsos","Era uno de prueba","Espera, ¿Qué está pasando?"};

        int ventana = JOptionPane.showOptionDialog(null,"¿Esta es su opción?","Indique si ha seleccionado bien la respuesta",JOptionPane.UNDEFINED_CONDITION, JOptionPane.INFORMATION_MESSAGE, null, botones, botones[0]);
        if (ventana == 0){
            System.out.println("Si, son correctos");
        }
        else{
            if (ventana == 1){
                System.out.println("No, son falsos");
            }
            else{
                if (ventana == 2){
                    System.out.println("Era uno de prueba");
                }
                else{
                    if (ventana == 3){
                        System.out.println("Espera, ¿Qué está pasando?");
                    }
                }
            }
        }

    }
}
