package com.company;

import Modelo.*;
import Vista.VentanaCompras;
import Vista.VentanaPrincipal;
import Vista.VentanaVentas;

import javax.swing.*;
import java.util.ArrayList;

public class Main {
    private static ArrayList<Producto> listaProductos;
    private static Producto p;
    private static JFrame vp,vc,vv;

    public static void main(String[] args)
    {
	    generarProductos();
        mostrarVentanaPrincipal();
    }

    public static void generarProductos()
    {
        listaProductos = new ArrayList<>();
        p = new Producto ("Manzanas",1.5f,100);
        listaProductos.add(p);
        p = new Producto ("Naranjas",2.5f,50);
        listaProductos.add(p);
        p = new Producto ("Patatas",3f,1000);
        listaProductos.add(p);
        listaProductos.add(new Producto ("Pimientos",1.5f,10));
        listaProductos.add(new Producto ("Fresas",4f,76));
        listaProductos.add(new Producto ("Nueces",10f,25));
    }

    /************ Gestión de ventanas ********/
    public static void mostrarVentanaPrincipal(){
        vp = new JFrame("VentanaPrincipal");
        vp.setContentPane(new VentanaPrincipal().getpPrincipal());
        vp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        vp.setLocationRelativeTo(null);
        vp.pack();
        vp.setVisible(true);

    }

    public static void comprar()
    {
        // Muestra la ventana compras.
        vc= new JFrame("VentanaCompras");
        vc.setContentPane(new VentanaCompras().getpPrincipal());
        vc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        vc.setLocationRelativeTo(null);
        vc.pack();
        vc.setVisible(true);

        vp.setVisible(false);
    }

    public static void vender()
    {
        // Muestra la ventanaa ventas
        vv = new JFrame("VentanaVentas");
        vv.setContentPane(new VentanaVentas().getpPrincipal());
        vv.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        vv.setLocationRelativeTo(null);
        vv.pack();
        vv.setVisible(true);

        vp.setVisible(false);

    }
    public static void volver(char c)
    {
        if (c == 'c')
        {
            // Vengo de una compra
            vc.dispose();
        }
        else
        {
            // Vengo de una venta.
            vv.dispose();
        }
        vp.setVisible(true);

    }

    /***** Compra *************************/
    public static boolean tenDatosCompra(String producto,float precio,int unidades)
    {
        p=fValidarProducto(producto);
        if (p!= null)
        {
            p.setPrecio(unidades,precio);
            p.setUnidadesCompra(unidades);
            return true;
        }
        return false;
    }

    public static Producto fValidarProducto(String producto)
    {
        // buscar en la "base de datos"
        int x;
        boolean encontrado = false;
        for(x=0;x< listaProductos.size() && !encontrado;x++)
            if (listaProductos.get(x).getNombre().equals(producto))
                encontrado = true;
        if (encontrado)
            return listaProductos.get(x-1);
        return null;

    }

    /********* Venta *********************/
    public static boolean tenDatosVenta(String producto,int unidades)
    {
        p=fValidarProducto(producto);
        if (p!= null)
        {
            return p.getUnidades() >= unidades;
        }
        return false;
    }

    public static float getPrecio()
    {
        return p.getPrecio();
    }

    public static void registraVenta(int unidades)
    {
        p.setUnidadesVenta(unidades);
    }

    /************** Salida *************/
     public static String getDatos()
     {
         StringBuilder datos = new StringBuilder();
         for(Producto p: listaProductos)
             datos.append(p.toString());
         return datos.toString();
     }
}
