package Vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.company.Main;

public class VentanaVentas {
    private JButton bAceptar;
    private JButton bCancelar;
    private JTextField tfUnidades;
    private JTextField tfImporte;
    private JTextField tfProducto;
    private JPanel pPrincipal;

    public VentanaVentas() {
        bCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.volver('v');
            }
        });
        bAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Enviar datos a Main para que registre la venta.
                Main.registraVenta(Integer.parseInt(tfUnidades.getText()));
                Main.volver('v');
            }
        });
        tfUnidades.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                onApFl();
            }
        });
        tfUnidades.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                super.focusLost(e);
                onApFl();
            }
        });
        bCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.volver('v');
            }
        });
    }

    public void onApFl()
    {
        // Action Performed o focuslost de la caja unidades.
        if (fValidar()) {
            boolean correcto = Main.tenDatosVenta(tfProducto.getText(), Integer.parseInt(tfUnidades.getText()));
            if (!correcto)
                JOptionPane.showMessageDialog(null, "Problemas con la venta. El nombre del producto no es correcto o no hay unidades disponbles");
            else
            {
                fMostrarImporte();
                bAceptar.setEnabled(true);
            }
        }
    }
    public void fMostrarImporte(){
        float importe = Integer.parseInt(tfUnidades.getText()) * Main.getPrecio();
        tfImporte.setText(String.valueOf(importe));
    }

    public boolean fValidar()
    {
        JTextField error=null;
        try
        {
            // Producto. Sin acceso a la "base de datos"
            if (tfProducto.getText().isEmpty())
            {
                error = tfProducto;
                throw new Exception("El nombre del producto es un dato obligatorio");
            }

            Pattern patron = Pattern.compile("^[A-Za-z]*$");
            Matcher m = patron.matcher(tfProducto.getText());
            if (!m.matches()) {
                error = tfProducto;
                throw new Exception("Nombre de producto no válido");
            }

            // Unidades
            if (tfUnidades.getText().isEmpty())
            {
                error = tfUnidades;
                throw new Exception("El número de unidades vendidas es un dato obligatorio");
            }
            patron = Pattern.compile("^[0-9]+$");
            m = patron.matcher(tfUnidades.getText());
            if (!m.matches()) {
                error = tfUnidades;
                throw new Exception("Indica unidades en formato numérico.");
            }


            // Datos de entrada correctos
            return true;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
            error.requestFocus();
            return false;
        }

    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("VentanaVentas");
        frame.setContentPane(new VentanaVentas().pPrincipal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getpPrincipal() {
        return pPrincipal;
    }
}
