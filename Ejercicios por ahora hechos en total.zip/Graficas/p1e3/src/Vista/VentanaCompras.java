package Vista;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.company.Main;

public class VentanaCompras {
    private JButton bAceptar;
    private JButton bCancelar;
    private JTextField tfProducto;
    private JTextField tfUnidades;
    private JTextField tfPrecio;
    private JPanel pPrincipal;

    public VentanaCompras() {
        bCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.volver('c');
            }
        });
        bAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Validar y enviar datos a Main
                if (fValidar()) {
                    boolean correcto = Main.tenDatosCompra(tfProducto.getText(), Float.parseFloat(tfPrecio.getText()), Integer.parseInt(tfUnidades.getText()));
                    if (!correcto)
                        JOptionPane.showMessageDialog(null,"Problemas con la compra. Compruebe el nombre del producto y si es correcto, avise a un administrador.");
                    else
                        // compra registrada. Volver a la ventana inicial.
                        Main.volver('c');

                }
            }
        });
        bCancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.volver('c');
            }
        });
    }

    public boolean fValidar()
    {
        JTextField error=null;
        try
        {
            // Producto. Sin acceso a la "base de datos"
            if (tfProducto.getText().isEmpty())
            {
                error = tfProducto;
                throw new Exception("El nombre del producto es un dato obligatorio");
            }

            Pattern patron = Pattern.compile("^[A-Za-z]*$");
            Matcher m = patron.matcher(tfProducto.getText());
            if (!m.matches()) {
                error = tfProducto;
                throw new Exception("Nombre de producto no válido");
            }

            // Unidades
            if (tfUnidades.getText().isEmpty())
            {
                error = tfUnidades;
                throw new Exception("El número de unidades compradas es un dato obligatorio");
            }
            patron = Pattern.compile("^[0-9]+$");
            m = patron.matcher(tfUnidades.getText());
            if (!m.matches()) {
                error = tfUnidades;
                throw new Exception("Indica unidades en formato numérico.");
            }

            // Precio
            if (tfPrecio.getText().isEmpty())
            {
                error = tfPrecio;
                throw new Exception("El precio del producto comprado es un dato obligatorio");
            }
            patron = Pattern.compile("^[0-9]+[.][0-9]{1,2}$");
            m = patron.matcher(tfPrecio.getText());
            if (!m.matches()) {
                error = tfUnidades;
                throw new Exception("Indica precio en formato numérico.");
            }

            // Datos de entrada correctos
            return true;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
            error.requestFocus();
            return false;
        }

    }

    public static void main(String[] args)
    {
        JFrame frame = new JFrame("VentanaCompras");
        frame.setContentPane(new VentanaCompras().pPrincipal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public JPanel getpPrincipal() {
        return pPrincipal;
    }
}
