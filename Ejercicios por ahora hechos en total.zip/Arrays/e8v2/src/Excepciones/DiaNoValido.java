package Excepciones;

public class DiaNoValido extends Exception{
}
