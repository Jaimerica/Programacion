package com.company;

import javax.swing.*;
import Excepciones.*;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {
        try
        {
            int[][] totalFaltas= new int[5][30]; //[30][5] 5 alumnos 30 días tiene el mes.
            int[] codigosAlumnos= new int[5];
            // Codigos de tipo String

            char continuar;

            do
            {
                controlFalta(codigosAlumnos,totalFaltas);
                continuar=controlContinuar();
            }
            while(continuar=='s');

            salidadatos(codigosAlumnos,totalFaltas);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getClass());
        }
    }

    private static void controlFalta(int[] codigosAlumnos,int[][] totalFaltas) throws Exception
    {
        boolean error = true;
        do
        {
            try
            {
                int x;

                int codigo = Integer.parseInt(JOptionPane.showInputDialog("Introduzca el codigo alumno"));

                for(x=0; x<codigosAlumnos.length && codigosAlumnos[x]!=0 && codigosAlumnos[x]!=codigo; x++){}
                if(x==codigosAlumnos.length)
                    // Ya tengo cinco y no coincide con ninguno
                    throw new CodigoNoValido();

                if (codigosAlumnos[x]==0)
                    // No está pero tengo sitio para ponerlo
                    codigosAlumnos[x]=codigo;

                int dia = solicitarDia();

                int faltasDia = Integer.parseInt(JOptionPane.showInputDialog("Introduzca el nro de faltas en el dia =>"));
                // la fila la marca el alumno y la columna el día del mes.
                totalFaltas[x][dia -1]= faltasDia;
                error = false;
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Los datos son numéricos");
            }
            catch(CodigoNoValido e)
            {
                StringBuilder texto= new StringBuilder("Los codigos permitidos son: \n");
                for (int codigosAlumno : codigosAlumnos)
                    texto.append(codigosAlumno).append(" ");
                JOptionPane.showMessageDialog(null, texto.toString());
            }
        }
        while(error);
    }

    private static char controlContinuar() throws Exception
    {
        // Podiamos poner el try
        char continuar=' ';
        while (continuar!='s' && continuar!='n')
        {
            continuar = JOptionPane.showInputDialog("Desea continuar <s/n> ").toLowerCase().charAt(0);
        }
        return continuar;
    }

    private static void salidadatos(int[] codigosAlumnos, int[][] totalFaltas) throws Exception
    {
        StringBuilder texto= new StringBuilder("El total de faltas de cada alumno es: \n");
        for(int y=0; y<codigosAlumnos.length && codigosAlumnos[y]!=0; y++)
        {
            int suma = 0;
            for(int x = 0; x < totalFaltas[y].length; x++)
                suma += totalFaltas[y][x];
            texto.append(codigosAlumnos[y]).append(" - ").append(suma).append("\n");
        }

        JOptionPane.showMessageDialog(null, texto.toString());
    }

    public static int solicitarDia() throws Exception{
        int dia=0;
        boolean error = true;
        do
        {
            try
            {
                dia = Integer.parseInt(JOptionPane.showInputDialog("Teclea el día del mes"));
                if (dia <= 0 || dia > 30)
                    throw new DiaNoValido();
                LocalDate fecha = LocalDate.of(LocalDate.now().getYear(),11,dia); // no me planteo excepción
                // Fin de semana
                if (fecha.getDayOfWeek().equals(DayOfWeek.SATURDAY) || fecha.getDayOfWeek().equals(DayOfWeek.SUNDAY))
                    throw new DiaNoValido();
                error = false;

            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null,"El día es un dato numérico");
            }
            catch(DiaNoValido e)
            {
                JOptionPane.showMessageDialog(null,"El día no está comprendido entre 1 y 30 o es fin de semana");
            }
        }
        while(error);
        return dia;
    }
}
