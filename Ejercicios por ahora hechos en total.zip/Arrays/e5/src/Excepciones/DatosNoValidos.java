package Excepciones;

public class DatosNoValidos extends Exception{
}
