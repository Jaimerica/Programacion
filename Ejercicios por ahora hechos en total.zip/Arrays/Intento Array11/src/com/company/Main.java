package com.company;

import javax.swing.*;

public class Main {
        private static String [][] productos;
        private static float [][] precios;
    public static void main(String[] args) {
	// write your code here
        int x;
        int y;
        String [][] productos = new String[4][4];
        productos[0][0] = "KitKat";
        productos[0][1] = "Chicles de fresa";
        productos[0][2] = "Lacasitos";
        productos[0][3] = "Palotes";
        productos[1][0] = "Kinder Bueno";
        productos[1][1] = "Bolsa variada Haribo";
        productos[1][2] = "Cheetos";
        productos[1][3] = "Twix";
        productos[2][0] = "Kinder Bueno";
        productos[2][1] = "M&M";
        productos[2][2] = "Papa Delta";
        productos[2][3] = "Chicles Menta";
        productos[3][0] = "Lacasitos";
        productos[3][1] = "Crunch";
        productos[3][2] = "Milkybar";
        productos[3][3] = "KitKat";

        float [][] precios = new float[4][4];
        precios[0][0] = 1.1f;
        precios[0][1] = 0.8f;
        precios[0][2] = 1.5f;
        precios[0][3] = 0.9f;
        precios[1][0] = 1.8f;
        precios[1][1] = 1f;
        precios[1][2] = 1.2f;
        precios[1][3] = 1f;
        precios[2][0] = 1.8f;
        precios[2][1] = 1.3f;
        precios[2][2] = 1.2f;
        precios[2][3] = 0.8f;
        precios[3][0] = 1.5f;
        precios[3][1] = 1.1f;
        precios[3][2] = 1.1f;
        precios[3][3] = 1.1f;

        int opcion=0;
        boolean correcto=false;
        do
        {
            try
            {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,"1.- Pide una golosina \n" +
                        "2.- Mostrar golosinas a disposición\n" +
                        "3.- Rellenar la máquina con [DELICIOSAS] golosinas\n" +
                        "4.- Apagar la máquina\n"));
                correcto = true;
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "La opción tiene que ser un número");
            }
        }
        while(!correcto);

        switch (opcion)
        {
            case 1:
                for (x=0; x<productos.length; x++)
                    for (y=0; y<productos[x].length;y++)
                        productos[x][y] = JOptionPane.showInputDialog("Selecciona un valor entre el 0 y el 3 de una fila y una columna del producto");
                break;
            case 2:
                for (x=0; x<productos.length; x++)
                    for (y=0; y<productos[x].length;y++)
                        JOptionPane.showMessageDialog(null,"La fila " + x + " y columna " + y + " tiene el producto " + productos[x][y]);
                    break;
            case 3:
                String contraseña = JOptionPane.showInputDialog("Ponga la contraseña");
                break;
            case 4:
                JOptionPane.showMessageDialog(null,"Hasta pronto, vuelva a comprar productos cuando quiera");
        }
    }
}
