package com.company;

import javax.swing.*;

public class Main {
    /* Crear un array de 10 elementos para guardar en el valores de tipo real
(float o double) que iremos introduciendo por teclado hasta finalizar.
Una vez le´ıdos y almacenados se visualizar´a el valor máximo y el
mínimo.*/

    public static void main(String[] args) {
        try
        {
            // Declaración y creación del array
            float[] arrayNumeros= new float[10];
            entradaDatos(arrayNumeros);
            salidaDatos(arrayNumeros);
            // arrayNumeros puede ser una variable global
        }
        catch(Exception e)
        {
            //No hago nada. El ejercicio acaba con código cero.
        }
    }

    private static void entradaDatos(float[] arrayNumeros) throws Exception
    {

        for(int x=0; x<arrayNumeros.length; x++)
        {
            try
            {
                arrayNumeros[x] = Float.parseFloat(JOptionPane.showInputDialog("Introduce el valor de la posición " + x));
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null,"Hay que teclear numeros.");
                x--;
            }
        }
        // return ?

    }

    private static void salidaDatos(float[] arrayNumeros) throws Exception
    {
        float cantidadMinima = arrayNumeros[0];
        float cantidadMaxima = arrayNumeros[0];

        for (int x = 1; x < arrayNumeros.length; x++)
        {
            if (arrayNumeros[x] < cantidadMinima)
                cantidadMinima = arrayNumeros[x];
            else
                if (arrayNumeros[x] > cantidadMaxima)
                    cantidadMaxima = arrayNumeros[x];
        }

        JOptionPane.showMessageDialog(null, "El maximo valor  " + cantidadMaxima+ " y el mínimo "+ cantidadMinima);
    }
}
