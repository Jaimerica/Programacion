package com.company;

import javax.swing.JOptionPane;
import Excepciones.*;

public class Main {

    public static void main(String[] args) {
        try
        {
            // Arrays coincidentes
            int[] totalFaltas= new int[5]; // contadores de faltas por alumnos
            String[] codigosAlumnos= new String[5]; // códigos de los alumnos

            char continuar;

            do
            {
                controlFalta(codigosAlumnos,totalFaltas);
                continuar=controlContinuar();
            }
            while(continuar=='s');

            salidadatos(codigosAlumnos,totalFaltas);
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getClass());
        }
    }

    private static void controlFalta(String[] codigosAlumnos,int[] totalFaltas) throws Exception
    {
        boolean error = true;
        do
        {
            try
            {
                int x;

                String codigo = JOptionPane.showInputDialog("Introduzca el codigo alumno");

                // x<codigosAlumnos.length  para comparar con todos
                // !codigosAlumnos[x].isEmpty() no está y encuentro un hueco para dejar el nuevo código
                //  !codigosAlumnos[x].equals(codigo) No es la primera vez que falta.
                for(x=0; x<codigosAlumnos.length && codigosAlumnos[x]!=null && !codigosAlumnos[x].equals(codigo); x++){}
                if(x==codigosAlumnos.length)
                    // Ya tengo cinco y no coincide con ninguno
                    throw new CodigoNoValido();

                if (codigosAlumnos[x]==null)
                    // No está pero tengo sitio para ponerlo
                    codigosAlumnos[x]=codigo;
                // else lo he encontrado
                int faltasDia = Integer.parseInt(JOptionPane.showInputDialog("Introduzca el nro de faltas en el dia =>"));
                if (faltasDia <= 0 || faltasDia > 6)
                        throw new FaltasNoValidas();
                totalFaltas[x]= totalFaltas[x]+faltasDia;
                error = false;
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null, "Los datos son numéricos");
            }
            catch(CodigoNoValido e)
            {
                StringBuilder texto= new StringBuilder("Los codigos permitidos son: \n");
                for (String codigosAlumno : codigosAlumnos) texto.append(codigosAlumno).append(" ");
                JOptionPane.showMessageDialog(null, texto.toString());
            }
            catch(FaltasNoValidas e)
            {
                JOptionPane.showMessageDialog(null, "Las faltas no pueden ser negativas o cero");
            }
        }
        while(error);
    }

    private static char controlContinuar() throws Exception
    {
        // Podemos poner el try
        char continuar=' ';
        while (continuar!='s' && continuar!='n')
        {
            continuar = JOptionPane.showInputDialog("Desea continuar <s/n> ").toLowerCase().charAt(0);
        }
        return continuar;
    }

    private static void salidadatos(String[] codigosAlumnos, int[] totalFaltas) throws Exception
    {
        StringBuilder texto= new StringBuilder("El total de faltas de cada alumno es: \n");
        for(int y=0; y<codigosAlumnos.length && !codigosAlumnos[y].isEmpty(); y++)
        {
            // texto=texto + codigosAlumnos[y]+ " - "+totalFaltas[y]+ "\n";
            texto.append(codigosAlumnos[y]).append(" - ").append(totalFaltas[y]).append("\n");
        }

        JOptionPane.showMessageDialog(null, texto.toString());
    }
}
