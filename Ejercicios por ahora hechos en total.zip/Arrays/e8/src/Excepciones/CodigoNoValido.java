package Excepciones;

public class CodigoNoValido extends Exception{
}
