package Excepciones;

public class FaltasNoValidas extends Exception{
}
