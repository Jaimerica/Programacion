package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int [][] tabla= new int[4][4];
        int x;
        int y;
        String opcion;
        opcion = JOptionPane.showInputDialog("Elige una opción: \n " +
                "a) Rellena la tabla \n" +
                "b) Sumar una fila \n" +
                "c) Sumar una columna \n" +
                "d) Sumar la diagonal principal \n" +
                "e) Sumar la diagonal inversa \n" +
                "f) Hacer la media de todos los valores \n" +
                "g) [SALIR]");
        switch (opcion)
        {
            case "a":
                for (x=0; x<tabla.length; x++)
                for (y=0; y<tabla[x].length;y++)
                    tabla[x][y] = Integer.parseInt(JOptionPane.showInputDialog("Dí un número del valor x " + x + " y valor y " + y ));
                break;
            case "b":
        }

    }
}
