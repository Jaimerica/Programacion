package com.company;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
	// write your code here
        try
        {
            float[] arrayNumeros= new float[10];
            entradaDatos(arrayNumeros);
            salidaDatos(arrayNumeros);
        }
        catch (Exception e)
        {

        }
    }
    private static void entradaDatos(float[] arrayNumeros) throws Exception
    {
        for(int x=0; x<arrayNumeros.length; x++)
        {
            try
            {
                arrayNumeros[x] = Float.parseFloat(JOptionPane.showInputDialog("Introduce el valor de la posición"));
            }
            catch (NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null,"Hay que teclear números");
                x--;
            }
        }
    }
    private static void salidaDatos(float[] arrayNumeros) throws Exception
    {
        float cantidadMinima = arrayNumeros[];
    }

}
