package com.company;

import javax.swing.JOptionPane;
import Excepciones.*;

public class Main {

    public static void main(String[] args) {
        try
        {
            //Inicializacion de un array con los valores de los billetes y monedas actuales
            float[] monedas= new float[14];
            InicializarArrayMonedas(monedas);

            //Entrada de datos -- Reutilización de la función
            float importeVenta = entradaDato("importe");
            float dineroEntregado = entradaDato("dinero");

            //Calcula los billetes y monedas de vuelta
            String dineroDeVuelta=CalculoDineroDeVuelta(importeVenta,dineroEntregado,monedas);

            //Salida de datos
            JOptionPane.showMessageDialog(null, dineroDeVuelta );
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Problemas " + e.getMessage());
        }
    }

    public static float entradaDato(String mensaje) throws Exception
    {
        boolean error = true;
        float cantidad=0;
        do
        {
            try
            {
                cantidad = Float.parseFloat(JOptionPane.showInputDialog("Introduzca el " + mensaje + " de la venta =>"));
                if (cantidad<= 0)
                    throw new DatoNoValido();
                error = false;
            }
            catch(NumberFormatException e)
            {
                JOptionPane.showMessageDialog(null,"El dato debe ser numérico");
            }
            catch(DatoNoValido  e)
            {
                JOptionPane.showMessageDialog(null,"El dato proporcionado no es lógico");
            }

        }
        while(error);
        return cantidad;
    }

    public static void InicializarArrayMonedas(float[] monedas)
    {
        monedas[0]=200f;
        monedas[1]=100f;
        monedas[2]=50f;
        monedas[3]=20f;
        monedas[4]=10f;
        monedas[5]=5f;
        monedas[6]=2f;
        monedas[7]=1f;
        monedas[8]=0.50f;
        monedas[9]=0.20f;
        monedas[10]=0.10f;
        monedas[11]=0.05f;
        monedas[12]=0.02f;
        monedas[13]=0.01f;
        // También se pueden indicar todos los valores entre {}
    }

    private static String CalculoDineroDeVuelta(float importeVenta, float dineroEntregado, float[] monedas) throws Exception
    {
        String vueltas="";
        float dineroVuelta = dineroEntregado - importeVenta;
        if (dineroVuelta < 0)
        {
            // Podriamos crear una nueva excepcion
            return "Falta dinero";
        }
        // else no hace falta
        if (dineroVuelta == 0)
            return "En paz. No hay vueltas";

        // Hay que dar vueltas
        JOptionPane.showMessageDialog(null, "Debemos devolver al cliente "+dineroVuelta+ " euros");

        float dineroQueQueda = dineroVuelta;
        int x=0;
        while (dineroQueQueda > 0)
        {
                // Redondeo a dos decimales. Math.rint devuelve double
                 dineroQueQueda = (float) Math.rint(dineroQueQueda*100)/100;


                int cont = 0; // Número de billetes o monedas
                while(dineroQueQueda>=monedas[x])
                {
                    cont++;
                    dineroQueQueda = dineroQueQueda - monedas[x];
                }
                if (cont != 0)
                    vueltas +=  "\nEntregar " + cont +  " billete(s) o moneda(s) de "+monedas[x]+" euros";
                x++;
        }
        return vueltas;
    }
}
