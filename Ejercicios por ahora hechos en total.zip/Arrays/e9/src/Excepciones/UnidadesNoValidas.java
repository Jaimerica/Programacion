package Excepciones;

public class UnidadesNoValidas extends Exception {
}
