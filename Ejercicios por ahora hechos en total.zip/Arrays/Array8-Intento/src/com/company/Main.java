package com.company;

import javax.swing.*;
import java.lang.reflect.Array;

public class Main {

    private static int[] cantidades= new int[10];

    public static void main(String[] args) {
	// write your code here
        int[] productos= new int[10];
        InicoArrayProductos(productos);
        int cantidad;
        int TotalCantidades;
        InicioArrayCantidades(cantidades);
        int x;
        try
        {
            int producto = Integer.parseInt(JOptionPane.showInputDialog(null,"Selecciona el producto"));
            for (x = 0; productos[x] != producto && x<productos.length; x++) {}
            if (x != productos.length)
            {
                Cuestioncantidades();
                Resultado();
                }
                else
                    JOptionPane.showMessageDialog(null,"No existe ese producto");
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null,"ERROR");
        }

    }

    public static void InicoArrayProductos(int[] productos)
    {
        productos[0]=10;
        productos[1]=23;
        productos[2]=30;
        productos[3]=47;
        productos[4]=55;
        productos[5]=65;
        productos[6]=135;
        productos[7]=256;
        productos[8]=526;
        productos[9]=663;
    }
    public static void InicioArrayCantidades(int[] cantidades)
    {
        cantidades[0]=0;
        cantidades[1]=0;
        cantidades[2]=0;
        cantidades[3]=0;
        cantidades[4]=0;
        cantidades[5]=0;
        cantidades[6]=0;
        cantidades[7]=0;
        cantidades[8]=0;
        cantidades[9]=0;
    }
    public static void Cuestioncantidades()
    {
        int cantidades = Integer.parseInt(JOptionPane.showInputDialog(null,"Selecciona la cantidad de productos"));

    }
    public static void Resultado()
    {
        JOptionPane.showMessageDialog(null,"Del producto");
    }
}
