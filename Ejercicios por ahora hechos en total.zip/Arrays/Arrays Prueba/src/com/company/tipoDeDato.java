package com.company;

public class tipoDeDato {
}
