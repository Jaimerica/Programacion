package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int dimension = 0;
        tipoDeDato [] nombre = new tipoDeDato [ dimension ];
        int[] listaNumeros = new int[5];
    }
}